# NetDevOps Enterprise Pipeline - VCB Bank Topology

[![CI](https://github.com/vuongtoantoi/netDevOps_Project/actions/workflows/ci.yml/badge.svg)](https://github.com/vuongtoantoi/netDevOps_Project/actions/workflows/ci.yml)
[![CD](https://github.com/vuongtoantoi/netDevOps_Project/actions/workflows/cd.yml/badge.svg)](https://github.com/vuongtoantoi/netDevOps_Project/actions/workflows/cd.yml)

Tự động hóa và giám sát mạng đa chi nhánh (10 thiết bị Cisco trong EVE-NG): cấu hình mạng được mô tả bằng YAML,
sinh lệnh IOS bằng Python, đẩy qua SSH (pexpect), và được kiểm thử/triển khai tự động bằng GitHub Actions.

![Topology](The_main_topology/Screenshot%20from%202026-09-25%2021-18-34.png)

## Pipeline

```mermaid
flowchart LR
    A["Sửa devices.yaml<br/>(nhánh riêng)"] --> B["Pull Request"]
    B --> C["CI - GitHub-hosted runner<br/>yamllint, flake8, unittest,<br/>validate, dry-run"]
    C -->|"xanh, merge vào master"| D["CD - self-hosted runner<br/>(máy Ubuntu trong mạng lab)"]
    D --> E["preflight"] --> F["backup"] --> G["deploy (pexpect/SSH)"] --> H["verify"]
    G --> L[("EVE-NG lab<br/>10 thiết bị")]
```

| Giai đoạn | Chạy ở đâu | Làm gì |
|---|---|---|
| **CI** | Máy ảo GitHub (offline) | Lint, 130+ unit test (thiết bị Cisco giả), `validate.py`, dry-run sinh lệnh cho 10 thiết bị |
| **CD** | Self-hosted runner trong mạng lab | Kiểm tra lại offline, `preflight` -> `backup` -> `deploy` -> `verify` |
| Cổng duyệt | GitHub Environment `lab` | Người duyệt bấm *Approve* trước khi chạm vào lab |

## Cấu trúc repo

| Thư mục | Nội dung |
|---|---|
| `main_project/` | Dữ liệu `devices.yaml`, `config_builder.py`, `deploy_pexpect.py`, `validate.py`, `preflight.py`, `backup.py`, `verify.py` |
| `tests/` | Unit test chạy offline + test chính sách bảo mật của repo |
| `.github/workflows/` | `ci.yml`, `cd.yml` |
| `netdevops-monitoring/` | Giai đoạn 3: Prometheus, Grafana, SNMP exporter, rsyslog, NTP/TFTP |
| `ansible-eveng/` | Cấu hình DHCP/DNS server bằng Ansible |
| `docs/` | Tài liệu pipeline ([CICD.md](docs/CICD.md)) |

## Chạy thử trên máy của bạn

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt -r requirements-dev.txt

python -m unittest discover -s tests            # test offline
python main_project/validate.py main_project/devices.yaml
python main_project/deploy_pexpect.py main_project/devices.yaml --dry-run --show-commands

# Chạm vào lab thật: điền credential trước (xem main_project/env.example)
cp main_project/env.example main_project/.env   # rồi sửa NETLAB_PASSWORD
python main_project/preflight.py main_project/devices.yaml
python main_project/deploy_pexpect.py main_project/devices.yaml --only HCM-SW
python main_project/verify.py main_project/devices.yaml
```

## Bảo mật (repo public + self-hosted runner)

Credential không nằm trong Git (chỉ trong GitHub Environment `lab` và file `.env` local đã bị `.gitignore`).
Workflow CD chỉ chạy khi chủ repo push vào `master` hoặc bấm chạy tay; người lạ gửi Pull Request chỉ chạy được CI
trên máy ảo của GitHub. Chi tiết và các test tự động bảo vệ những quy tắc này nằm trong [docs/CICD.md](docs/CICD.md).

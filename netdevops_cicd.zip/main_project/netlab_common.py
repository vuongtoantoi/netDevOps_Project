"""Tiện ích dùng chung cho các script NetDevOps (deploy / preflight / backup / verify).

- Đọc credential từ biến môi trường (hoặc file .env khi chạy local); KHÔNG lưu trong YAML/Git.
- Lọc các dòng lỗi của Cisco IOS ("% Invalid input ...", "% Duplicate sequence number"...).
- Ghi tóm tắt vào GitHub Actions "Step Summary" và in annotation (::error / ::warning).
- Chuẩn hóa tên interface (e1/0 == Ethernet1/0) để so sánh với output của thiết bị.
"""
import os
import re

ENV_USER = "NETLAB_USERNAME"
ENV_PASS = "NETLAB_PASSWORD"
ENV_ENABLE = "NETLAB_ENABLE_PASSWORD"


class CredentialError(RuntimeError):
    """Thiếu username/password để đăng nhập thiết bị."""


# ---------------------------------------------------------------------------
# Credential
# ---------------------------------------------------------------------------

def _parse_env_file(path, environ):
    with open(path, encoding="utf-8") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            if line.startswith("export "):
                line = line[len("export "):].lstrip()
            key, _, value = line.partition("=")
            key, value = key.strip(), value.strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
                value = value[1:-1]
            if key and key not in environ:      # không ghi đè biến đã được export / CI secret
                environ[key] = value


def load_dotenv(path=None, environ=None):
    """Nạp KEY=VALUE từ file .env vào environ (không ghi đè biến đã có).

    Thứ tự tìm file: tham số `path` -> $NETLAB_ENV_FILE -> ./.env -> <thư mục script>/.env
    Trả về True nếu đã nạp một file. Trên CI không có file .env -> trả về False (bình thường).
    """
    environ = os.environ if environ is None else environ
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [path, environ.get("NETLAB_ENV_FILE"), ".env", os.path.join(here, ".env")]
    for cand in candidates:
        if cand and os.path.isfile(cand):
            _parse_env_file(cand, environ)
            return True
    return False


def resolve_credentials(device, environ=None):
    """Trả về dict {username, password, enable_password} cho 1 thiết bị.

    Ưu tiên biến môi trường NETLAB_*; nếu không có mới lấy từ YAML (kiểu cũ, chỉ để tương thích).
    enable_password mặc định = password (thiết bị lab đăng nhập thẳng vào mode '#').
    """
    env = os.environ if environ is None else environ
    username = env.get(ENV_USER) or device.get("username")
    password = env.get(ENV_PASS) or device.get("password")
    enable = env.get(ENV_ENABLE) or device.get("enable_password") or password
    missing = [n for n, v in ((ENV_USER, username), (ENV_PASS, password)) if not v]
    if missing:
        raise CredentialError(
            f"Thiếu credential: {', '.join(missing)}. "
            f"Local: đặt trong file .env (xem env.example). CI: đặt trong GitHub Secrets."
        )
    return {"username": username, "password": password, "enable_password": enable}


# ---------------------------------------------------------------------------
# Lọc lỗi của Cisco IOS
# ---------------------------------------------------------------------------

# Dòng lỗi IOS bắt đầu bằng '%' ở đầu dòng. Loại trừ syslog dạng %FACILITY-severity-MNEMONIC:
_IOS_PERCENT_LINE = re.compile(r"^%(?![A-Z0-9_]+-\d-[A-Z0-9_]+:)\s*\S")
# Các thông báo bắt đầu bằng '%' nhưng chỉ mang tính thông tin (thấy trong log thật của lab).
_IOS_BENIGN = re.compile(
    r"^%\s*(Warning:|Portfast has been configured|Not all config may be removed)", re.IGNORECASE
)


def find_error_lines(text):
    """Trả về list các dòng lỗi IOS trong `text` (output của 1 lệnh)."""
    errors = []
    for raw in (text or "").replace("\r", "").split("\n"):
        line = raw.strip()
        if _IOS_PERCENT_LINE.match(line) and not _IOS_BENIGN.match(line):
            errors.append(line)
    return errors


# ---------------------------------------------------------------------------
# GitHub Actions helpers
# ---------------------------------------------------------------------------

def write_step_summary(markdown, environ=None):
    """Ghi markdown vào $GITHUB_STEP_SUMMARY (nếu đang chạy trong GitHub Actions)."""
    env = os.environ if environ is None else environ
    path = env.get("GITHUB_STEP_SUMMARY")
    if not path:
        return False
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(markdown.rstrip() + "\n\n")
    return True


def _escape_data(value):
    return value.replace("%", "%25").replace("\r", "%0D").replace("\n", "%0A")


def _escape_prop(value):
    return _escape_data(value).replace(":", "%3A").replace(",", "%2C")


def annotate(level, message, title=None, file=None):
    """In annotation của GitHub Actions: level = notice | warning | error."""
    if os.environ.get("GITHUB_ACTIONS") != "true":
        return
    props = []
    if file:
        props.append(f"file={_escape_prop(file)}")
    if title:
        props.append(f"title={_escape_prop(title)}")
    head = f"::{level} {','.join(props)}::" if props else f"::{level}::"
    print(f"{head}{_escape_data(message)}")


# ---------------------------------------------------------------------------
# Chuẩn hóa tên interface
# ---------------------------------------------------------------------------

_IFACE_FULL = [
    "ethernet", "fastethernet", "gigabitethernet", "tengigabitethernet",
    "vlan", "port-channel", "tunnel", "loopback", "serial",
]


def canon_iface(name):
    """'e1/0' / 'Ethernet1/0' -> 'ethernet1/0'; 'Po1' -> 'port-channel1'; 'fa0/0.210' -> 'fastethernet0/0.210'."""
    text = str(name).strip()
    m = re.match(r"^([A-Za-z-]+)\s*(\d.*)$", text)
    if not m:
        return text.lower()
    prefix, rest = m.group(1).lower(), m.group(2)
    for full in _IFACE_FULL:
        if full.startswith(prefix):
            return f"{full}{rest}"
    return f"{prefix}{rest}"

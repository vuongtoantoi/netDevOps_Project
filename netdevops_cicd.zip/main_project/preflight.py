"""preflight.py - kiểm tra lab đã sẵn sàng TRƯỚC khi deploy.

Mục đích: nếu EVE-NG chưa bật hoặc 1 node đang tắt, pipeline phải dừng sớm với thông báo rõ
"thiết bị X không kết nối được" thay vì deploy dở dang rồi lỗi giữa chừng.

Hai tầng kiểm tra:
  1) TCP tới host:port (chạy song song, nhanh)
  2) Đăng nhập SSH + chạy 'show clock' (tuần tự) - có thể bỏ bằng --tcp-only

Cách dùng:
    python3 preflight.py devices.yaml
    python3 preflight.py devices.yaml --tcp-only
    python3 preflight.py devices.yaml --only HN_GW HCM_GW

Exit code: 0 = tất cả sẵn sàng | 1 = có thiết bị không sẵn sàng | 2 = sai tham số / thiếu credential.
"""
import argparse
import socket
import sys
from concurrent.futures import ThreadPoolExecutor

import deploy_pexpect as dp
import netlab_common as nc


def tcp_check(host, port, timeout=3.0):
    """Trả về (True, '') nếu mở được kết nối TCP, ngược lại (False, lý do)."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True, ""
    except OSError as e:
        return False, f"{type(e).__name__}: {e}"


def ssh_check(device, log_dir):
    """Đăng nhập thật và chạy 'show clock'. Trả về (True, đồng hồ thiết bị) hoặc (False, lý do)."""
    child = None
    try:
        child = dp.connect(device, log_dir)
        clock = dp.run_command(child, "show clock").strip().splitlines()
        child.sendline("exit")
        return True, clock[-1].strip() if clock else ""
    except Exception as e:  # noqa: BLE001
        return False, f"{type(e).__name__}: {e}"
    finally:
        dp.close_session(child)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="+", help="file YAML thiết bị")
    ap.add_argument("--only", nargs="*", help="chỉ kiểm tra các thiết bị có tên này")
    ap.add_argument("--tcp-only", action="store_true", help="chỉ kiểm tra TCP, không đăng nhập SSH")
    ap.add_argument("--timeout", type=float, default=3.0, help="timeout TCP mỗi thiết bị (giây)")
    ap.add_argument("--log-dir", default="logs", help="thư mục log phiên SSH")
    args = ap.parse_args(argv)
    nc.load_dotenv()

    try:
        devices = dp.load_devices(args.files, args.only)
        if not args.tcp_only:
            for d in devices:
                d.update(nc.resolve_credentials(d))
    except (ValueError, OSError, nc.CredentialError) as e:
        print(f"LỖI: {e}")
        return 2

    with ThreadPoolExecutor(max_workers=min(10, max(1, len(devices)))) as pool:
        tcp_results = list(pool.map(lambda d: tcp_check(d["host"], d.get("port", 22), args.timeout), devices))

    rows, failed = [], []
    for dev, (tcp_ok, tcp_msg) in zip(devices, tcp_results):
        name, host = dev["name"], dev["host"]
        if not tcp_ok:
            status, detail = "FAIL", f"TCP {dev.get('port', 22)} không mở ({tcp_msg})"
        elif args.tcp_only:
            status, detail = "OK", "TCP mở"
        else:
            ok, msg = ssh_check(dev, args.log_dir)
            status, detail = ("OK", f"SSH đăng nhập được; đồng hồ thiết bị: {msg}") if ok else ("FAIL", f"SSH: {msg}")
        print(f"{status:5s} {name:15s} {host:15s} {detail}")
        rows.append((name, host, status, detail))
        if status == "FAIL":
            failed.append(name)
            nc.annotate("error", f"{name} ({host}): {detail}", title="Preflight")

    print(f"\nPreflight: {len(rows) - len(failed)}/{len(rows)} thiết bị sẵn sàng.")
    if failed:
        print(f"Thiết bị chưa sẵn sàng: {failed}. Kiểm tra EVE-NG đã bật lab và các node đã boot xong chưa.")

    lines = [f"### Preflight: {len(rows) - len(failed)}/{len(rows)} thiết bị sẵn sàng", "",
             "| Thiết bị | IP | Kết quả | Chi tiết |", "|---|---|---|---|"]
    lines += [f"| {n} | {h} | {'✅' if s == 'OK' else '❌'} | {d} |" for n, h, s, d in rows]
    nc.write_step_summary("\n".join(lines))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())

"""Test "chính sách": repo này PUBLIC và có self-hosted runner nối vào lab, nên các quy tắc an toàn
được kiểm tra tự động. Nếu ai đó (kể cả chính bạn) vô tình vi phạm, CI sẽ đỏ trước khi merge."""
import os
import re
import subprocess
import unittest

import yaml

import _fakes

ROOT = _fakes.ROOT
WORKFLOWS = os.path.join(ROOT, ".github", "workflows")
TEXT_EXT = (".yaml", ".yml", ".md", ".txt", ".py", ".sh", ".j2", ".cfg", ".ini", ".json", ".toml", ".example")
SKIP_DIRS = {".git", ".venv", "venv", "__pycache__", "logs", "node_modules", "data"}

# Gán giá trị cứng cho biến có tên chứa password/secret, vd:  password: abc123   |   NETLAB_PASSWORD=abc123
# Giá trị chứa < $ { [ ( hoặc khoảng trắng (placeholder, biến, tham chiếu code) không bị tính.
SECRET_ASSIGN = re.compile(
    r"(?i)[A-Za-z_]*(password|passwd|secret)[A-Za-z_]*\s*[:=]\s*[\"']?([A-Za-z0-9!@#%^&*._+-]{4,})[\"']?\s*$"
)


def tracked_files():
    """File được Git theo dõi (trong CI chính là toàn bộ workspace). Không có .git thì duyệt thư mục."""
    if os.path.isdir(os.path.join(ROOT, ".git")):
        try:
            out = subprocess.run(["git", "ls-files"], cwd=ROOT, capture_output=True, text=True, check=True).stdout
            return [f for f in out.splitlines() if os.path.isfile(os.path.join(ROOT, f))]
        except (OSError, subprocess.CalledProcessError):
            pass
    found = []
    for base, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        found += [os.path.relpath(os.path.join(base, f), ROOT) for f in files]
    return found


def load_workflows():
    result = {}
    for name in sorted(os.listdir(WORKFLOWS)):
        if name.endswith((".yml", ".yaml")):
            with open(os.path.join(WORKFLOWS, name), encoding="utf-8") as fh:
                result[name] = yaml.safe_load(fh)
    return result


def triggers_of(workflow):
    """PyYAML đọc khoá 'on:' thành True (quy tắc YAML 1.1), nên phải thử cả hai."""
    on = workflow.get("on", workflow.get(True))
    if isinstance(on, str):
        return {on}
    if isinstance(on, list):
        return set(on)
    return set(on or {})


def all_steps(workflow):
    for job in (workflow.get("jobs") or {}).values():
        yield from job.get("steps") or []


class SecretHygieneTests(unittest.TestCase):
    def test_co_gitignore_chan_env_va_log(self):
        with open(os.path.join(ROOT, ".gitignore"), encoding="utf-8") as fh:
            patterns = {line.strip() for line in fh if line.strip() and not line.startswith("#")}
        for required in (".env", "logs/", "__pycache__/"):
            self.assertIn(required, patterns, f".gitignore thiếu '{required}'")

    def test_khong_co_file_env_nao_bi_theo_doi(self):
        bad = [f for f in tracked_files()
               if os.path.basename(f).startswith(".env") and os.path.basename(f) != ".env.example"]
        self.assertEqual(bad, [], f"file .env không được commit: {bad}")

    def test_khong_co_log_phien_ssh_bi_theo_doi(self):
        bad = [f for f in tracked_files() if f.endswith(".log") or f.split("/")[0] == "logs"]
        self.assertEqual(bad, [], f"log phiên SSH chứa cấu hình thiết bị: {bad}")

    def test_khong_co_mat_khau_cung_trong_file_van_ban(self):
        offenders = []
        for rel in tracked_files():
            if rel.startswith("tests/") or not rel.endswith(TEXT_EXT):
                continue
            with open(os.path.join(ROOT, rel), encoding="utf-8", errors="ignore") as fh:
                for number, line in enumerate(fh, 1):
                    if SECRET_ASSIGN.search(line.strip()):
                        offenders.append(f"{rel}:{number}")
        self.assertEqual(offenders, [], "nghi ngờ mật khẩu/secret ghi cứng tại: " + ", ".join(offenders))

    def test_bo_quet_nhan_ra_mat_khau_that(self):
        """Đảm bảo chính bộ quét hoạt động (không bị 'mù')."""
        for line in ("password: cisco123", "NETLAB_PASSWORD=abc123", "enable_password: 'Abc!2345'",
                     'password = "hunter22"', "GF_SECURITY_ADMIN_PASSWORD=admin1234"):
            self.assertTrue(SECRET_ASSIGN.search(line), line)
        for line in ("NETLAB_PASSWORD=<dien-mat-khau>", "password = device['password']",
                     "NETLAB_PASSWORD: ${{ secrets.NETLAB_PASSWORD }}", "GF_X_PASSWORD=${GRAFANA_PASSWORD}",
                     "NETLAB_ENABLE_PASSWORD=", 'ENV_PASS = "NETLAB_PASSWORD"'):
            self.assertFalse(SECRET_ASSIGN.search(line), line)

    def test_devices_yaml_khong_chua_khoa_credential(self):
        with open(_fakes.DEVICES_YAML, encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
        for dev in data["devices"]:
            for key in ("password", "enable_password", "secret", "enable_secret"):
                self.assertNotIn(key, dev, f"{dev['name']} còn khoá '{key}'")


class WorkflowPolicyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.workflows = load_workflows()

    def test_co_ci_va_cd(self):
        self.assertIn("ci.yml", self.workflows)
        self.assertIn("cd.yml", self.workflows)

    def test_chi_cd_moi_duoc_dung_self_hosted_runner(self):
        for name, wf in self.workflows.items():
            uses_self_hosted = any("self-hosted" in str(job.get("runs-on")) for job in wf["jobs"].values())
            self.assertEqual(uses_self_hosted, name == "cd.yml", f"{name}: self-hosted chỉ dành cho cd.yml")

    def test_cd_chi_duoc_kich_hoat_boi_push_hoac_chay_tay(self):
        """Nếu cd.yml (chạy trong mạng lab) nhận pull_request thì người lạ có thể chạy code trên máy bạn."""
        self.assertEqual(triggers_of(self.workflows["cd.yml"]), {"push", "workflow_dispatch"})
        on = self.workflows["cd.yml"].get("on", self.workflows["cd.yml"].get(True))
        self.assertEqual(on["push"]["branches"], ["master"])

    def test_khong_dung_pull_request_target(self):
        for name, wf in self.workflows.items():
            self.assertNotIn("pull_request_target", triggers_of(wf), name)

    def test_cd_dung_environment_co_secrets(self):
        job = self.workflows["cd.yml"]["jobs"]["deploy"]
        self.assertEqual(job.get("environment"), "lab")
        self.assertIn("netlab", job["runs-on"])

    def test_cd_khong_huy_giua_chung(self):
        concurrency = self.workflows["cd.yml"]["concurrency"]
        self.assertIs(concurrency["cancel-in-progress"], False)
        self.assertTrue(self.workflows["cd.yml"]["jobs"]["deploy"].get("timeout-minutes"))

    def test_quyen_gitub_token_toi_thieu(self):
        for name, wf in self.workflows.items():
            self.assertEqual(wf.get("permissions"), {"contents": "read"}, f"{name}: cần permissions: contents: read")

    def test_action_duoc_ghim_phien_ban(self):
        pinned = re.compile(r"^[\w.-]+/[\w./-]+@(v\d+(\.\d+){0,2}|[0-9a-f]{40})$")
        for name, wf in self.workflows.items():
            for step in all_steps(wf):
                if "uses" in step:
                    self.assertRegex(step["uses"], pinned, f"{name}: action chưa ghim phiên bản: {step['uses']}")

    def test_checkout_khong_giu_token(self):
        for name, wf in self.workflows.items():
            for step in all_steps(wf):
                if step.get("uses", "").startswith("actions/checkout@"):
                    self.assertIs(step.get("with", {}).get("persist-credentials"), False, name)

    def test_khong_noi_chuoi_do_nguoi_dung_nhap_vao_lenh_shell(self):
        """Chống script injection: input/ngữ cảnh sự kiện phải đi qua biến môi trường, không nằm trong 'run:'."""
        dangerous = re.compile(r"\$\{\{\s*(github\.event|github\.head_ref|inputs\.)")
        for name, wf in self.workflows.items():
            for step in all_steps(wf):
                self.assertIsNone(dangerous.search(step.get("run", "")), f"{name}: {step.get('name')}")

    def test_ci_ghim_phien_ban_he_dieu_hanh(self):
        for job in self.workflows["ci.yml"]["jobs"].values():
            self.assertNotEqual(job["runs-on"], "ubuntu-latest")

    def test_cd_chay_du_cac_buoc_theo_dung_thu_tu(self):
        runs = " ".join(step.get("run", "") for step in all_steps(self.workflows["cd.yml"]))
        order = ["unittest", "validate.py", "preflight.py", "backup.py", "deploy_pexpect.py", "verify.py"]
        positions = [runs.index(token) for token in order]
        self.assertEqual(positions, sorted(positions))


class RequirementsTests(unittest.TestCase):
    def test_requirements_du_thu_vien_chay_pipeline(self):
        with open(os.path.join(ROOT, "requirements.txt"), encoding="utf-8") as fh:
            text = fh.read().lower()
        self.assertIn("pexpect", text)
        self.assertIn("pyyaml", text)


if __name__ == "__main__":
    unittest.main()

"""verify.py - kiểm thử SAU deploy: mạng có thực sự chạy đúng như YAML mô tả không?

Mọi kỳ vọng được SUY RA TỪ devices.yaml (không hard-code), nên thêm VLAN/link mới thì verify tự cập nhật:
  1) Interface: có đúng IP, không bị 'administratively down' (show ip interface brief)
  2) VLAN:      mỗi VLAN khai báo phải tồn tại, đúng tên, active (show vlan brief) - chỉ với switch
  3) OSPF:      số láng giềng FULL >= số láng giềng kỳ vọng suy ra từ topology (show ip ospf neighbor)
  4) Ping:      mỗi thiết bị ping được IP đầu kia của từng liên kết point-to-point

Mức độ: lỗi cấu hình/OSPF/ping => FAIL (exit 1). 'line protocol down' => WARN (không làm thất bại).

Cách dùng:
    python3 verify.py devices.yaml
    python3 verify.py devices.yaml --only HN_GW
    python3 verify.py devices.yaml --warn-only     # in kết quả nhưng luôn exit 0 (dùng khi mới hiệu chỉnh)

Exit code: 0 = đạt | 1 = có kiểm tra thất bại | 2 = sai tham số / thiếu credential.
"""
import argparse
import re
import sys

import config_builder as cb
import deploy_pexpect as dp
import netlab_common as nc
import topology as tp

PING_MIN_SUCCESS = 60   # % - gói đầu thường rớt do ARP nên không đòi 100%


def check(ok, name, detail="", level="error"):
    """Một kết quả kiểm tra. level: 'error' (FAIL làm CI đỏ) hoặc 'warn'."""
    return {"ok": ok, "name": name, "detail": detail, "level": level}


# ---------------------------------------------------------------------------
# Parser output của IOS (thuần hàm, test được offline)
# ---------------------------------------------------------------------------

def parse_ip_interface_brief(text):
    """'show ip interface brief' -> {tên chuẩn hóa: {name, ip, status, protocol}}."""
    table = {}
    for line in text.replace("\r", "").splitlines():
        parts = line.split()
        if len(parts) < 6 or parts[2] not in ("YES", "NO"):
            continue
        table[nc.canon_iface(parts[0])] = {
            "name": parts[0], "ip": parts[1],
            "status": " ".join(parts[4:-1]).lower(), "protocol": parts[-1].lower(),
        }
    return table


def parse_vlan_brief(text):
    """'show vlan brief' -> {vlan_id: {name, status}}."""
    vlans = {}
    for line in text.replace("\r", "").splitlines():
        m = re.match(r"^(\d+)\s+(\S+)\s+(active|act/\S+|suspend|sus/\S+)", line)
        if m:
            vlans[int(m.group(1))] = {"name": m.group(2), "status": m.group(3)}
    return vlans


_OSPF_ROW = re.compile(
    r"^(?P<rid>\d+(?:\.\d+){3})\s+(?P<pri>\d+)\s+(?P<state>[A-Z0-9]+)(?:/\s*(?P<role>[A-Za-z-]+))?\s+"
    r"(?P<dead>\S+)\s+(?P<addr>\d+(?:\.\d+){3})\s+(?P<iface>\S+)\s*$"
)


def parse_ospf_neighbors(text):
    """'show ip ospf neighbor' -> list dict(rid, state, role, addr, iface)."""
    neighbors = []
    for line in text.replace("\r", "").splitlines():
        m = _OSPF_ROW.match(line.strip())
        if m:
            neighbors.append({k: m.group(k) for k in ("rid", "state", "role", "addr", "iface")})
    return neighbors


def parse_ping_success(text):
    """Tỉ lệ thành công (0-100) của lệnh ping IOS, hoặc None nếu không đọc được."""
    m = re.search(r"Success rate is (\d+) percent", text)
    return int(m.group(1)) if m else None


# ---------------------------------------------------------------------------
# Các phép kiểm tra (nhận output đã có sẵn -> test được offline)
# ---------------------------------------------------------------------------

def check_interfaces(dev, table):
    results = []
    for itf in tp.l3_interfaces(dev):
        label = f"interface {itf['name']} ({itf['ip']})"
        row = table.get(nc.canon_iface(itf["name"]))
        if row is None:
            results.append(check(False, label, "không thấy trong 'show ip interface brief'"))
        elif row["ip"] != itf["ip"]:
            results.append(check(False, label, f"IP trên thiết bị là {row['ip']}"))
        elif itf["shutdown"]:
            ok = row["status"].startswith("administratively")
            results.append(check(ok, label, "" if ok else "YAML đặt shutdown nhưng interface vẫn bật"))
        elif row["status"].startswith("administratively"):
            results.append(check(False, label, "đang 'administratively down' dù YAML không shutdown"))
        elif row["protocol"] != "up":
            results.append(check(False, label, f"line protocol {row['protocol']} (status {row['status']})",
                                 level="warn"))
        else:
            results.append(check(True, label))
    return results


def check_vlans(dev, parsed):
    results = []
    try:
        expected = cb.normalize_vlans(dev)
    except cb.DeviceConfigError:
        return results
    for vid, vname in sorted(expected.items()):
        label = f"vlan {vid} ({vname})"
        row = parsed.get(vid)
        if row is None:
            results.append(check(False, label, "không tồn tại trên thiết bị"))
        elif row["name"] != vname:
            results.append(check(False, label, f"tên trên thiết bị là '{row['name']}'"))
        elif not row["status"].startswith("act"):
            results.append(check(False, label, f"trạng thái {row['status']}"))
        else:
            results.append(check(True, label))
    return results


def check_ospf(neighbors, expected):
    full = [n for n in neighbors if n["state"] == "FULL"]
    others = [n for n in neighbors if n["state"] != "FULL"]
    label = f"ospf: {expected} láng giềng FULL kỳ vọng"
    results = []
    if len(full) >= expected:
        results.append(check(True, label, f"thực tế {len(full)} FULL"))
    else:
        seen = ", ".join(f"{n['rid']}={n['state']}" for n in neighbors) or "không có láng giềng nào"
        results.append(check(False, label, f"chỉ có {len(full)} FULL ({seen})"))
    if others:
        results.append(check(False, "ospf: láng giềng chưa FULL",
                             ", ".join(f"{n['rid']}={n['state']}" for n in others), level="warn"))
    return results


def check_ping(target, output):
    label = f"ping {target}"
    rate = parse_ping_success(output)
    if rate is None:
        return check(False, label, "không đọc được kết quả ping")
    if rate < PING_MIN_SUCCESS:
        return check(False, label, f"thành công {rate}% (cần >= {PING_MIN_SUCCESS}%)")
    return check(True, label, f"thành công {rate}%")


def collect_checks(dev, run, expected_neighbors, ping_targets):
    """Chạy các lệnh show/ping qua `run(lệnh, timeout)` và trả về list kết quả kiểm tra."""
    results = check_interfaces(dev, parse_ip_interface_brief(run("show ip interface brief", dp.CMD_TIMEOUT)))
    if not cb.is_router_schema(dev) and dev.get("vlans"):
        results += check_vlans(dev, parse_vlan_brief(run("show vlan brief", dp.CMD_TIMEOUT)))
    if expected_neighbors is not None:
        results += check_ospf(parse_ospf_neighbors(run("show ip ospf neighbor", dp.CMD_TIMEOUT)), expected_neighbors)
    for target in ping_targets:
        results.append(check_ping(target, run(f"ping {target}", 40)))
    return results


def ping_targets_by_device(devices):
    """{tên thiết bị: [IP đầu kia của mỗi liên kết point-to-point]}."""
    targets = {d["name"]: [] for d in devices}
    for a, b in tp.link_peers(devices):
        targets[a[0]].append(b[1])
        targets[b[0]].append(a[1])
    return targets


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def verify_device(dev, expected, targets, log_dir):
    child = None
    try:
        child = dp.connect(dev, log_dir)
        results = collect_checks(dev, lambda cmd, t: dp.run_command(child, cmd, timeout=t),
                                 expected.get(dev["name"]), targets.get(dev["name"], []))
        child.sendline("exit")
        return results
    except Exception as e:  # noqa: BLE001
        return [check(False, "kết nối SSH", f"{type(e).__name__}: {e}")]
    finally:
        dp.close_session(child)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="+", help="file YAML thiết bị")
    ap.add_argument("--only", nargs="*", help="chỉ kiểm tra các thiết bị có tên này")
    ap.add_argument("--warn-only", action="store_true", help="luôn exit 0, chỉ in kết quả")
    ap.add_argument("--log-dir", default="logs", help="thư mục log phiên SSH")
    args = ap.parse_args(argv)
    nc.load_dotenv()

    try:
        all_devices = dp.load_devices(args.files)
        selected = dp.load_devices(args.files, args.only)
        for d in selected:
            d.update(nc.resolve_credentials(d))
    except (ValueError, OSError, nc.CredentialError) as e:
        print(f"LỖI: {e}")
        return 2

    expected = tp.expected_ospf_neighbors(all_devices)       # tính trên TOÀN BỘ topology, kể cả khi --only
    targets = ping_targets_by_device(all_devices)

    failures, warnings, lines = 0, 0, []
    for dev in selected:
        print(f"\n=== {dev['name']} ({dev['host']}) ===")
        results = verify_device(dev, expected, targets, args.log_dir)
        for r in results:
            tag = "PASS" if r["ok"] else ("WARN" if r["level"] == "warn" else "FAIL")
            print(f"  {tag}  {r['name']}" + (f" - {r['detail']}" if r["detail"] else ""))
            if not r["ok"]:
                if r["level"] == "warn":
                    warnings += 1
                    nc.annotate("warning", f"{dev['name']}: {r['name']} - {r['detail']}", title="Verify")
                else:
                    failures += 1
                    nc.annotate("error", f"{dev['name']}: {r['name']} - {r['detail']}", title="Verify")
                    lines.append(f"| {dev['name']} | ❌ | {r['name']} | {r['detail']} |")
        passed = sum(1 for r in results if r["ok"])
        print(f"  -> {passed}/{len(results)} kiểm tra đạt")

    print(f"\nVERIFY: {failures} thất bại, {warnings} cảnh báo.")
    summary = [f"### Verify sau deploy: {failures} thất bại, {warnings} cảnh báo"]
    if lines:
        summary += ["", "| Thiết bị | | Kiểm tra | Chi tiết |", "|---|---|---|---|"] + lines
    nc.write_step_summary("\n".join(summary))
    if failures and args.warn_only:
        print("(--warn-only: bỏ qua thất bại, exit 0)")
        return 0
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())

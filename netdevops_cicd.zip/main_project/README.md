# config_builder.py
config_builder.py
------------------
Doc file YAML (routers: FPT_Telecom/HCM_GW/HN_GW va switches: HCM-SW/HN-DMZ/
FPT-SW/OFFICE-ACC1/OFFICE-ACC2/HN-OFFICE/HN-DATACENTER), chuan hoa du lieu, va
sinh ra danh sach cau lenh Cisco IOS (config mode) cho tung thiet bi.

Module nay KHONG dung pexpect / khong ket noi thiet bi that - chi xu ly du
lieu + sinh lenh, de co the test doc lap (dry-run) truoc khi day len switch/
router that qua deploy_pexpect.py.

Cach dung nhanh:
    python3 config_builder.py devices.yaml --dry-run

# deploy_pexpect.py
deploy_pexpect.py
------------------
Day cau hinh (sinh boi config_builder.py) len tung thiet bi Cisco IOS qua
SSH, dung pexpect - KHONG dung netmiko/paramiko.

Vi sao netmiko/paramiko hay "khong dung duoc" voi lab GNS3/EVE-NG/Packet
Tracer:
Netmiko chay tren Paramiko. Cac ban Paramiko/OpenSSH gan day mac dinh TAT
nhieu thuat toan SSH "cu" (vd key-exchange diffie-hellman-group1-sha1,
host-key ssh-rsa, mot so cipher CBC...) vi ly do bao mat. Cac IOS image hay
dung trong lab (c3725/c3745/c7200/mot so IOSv doi cu) lai CHI ho tro dung
nhung thuat toan cu nay -> Paramiko/Netmiko bao loi dang "Unable to
negotiate kex algorithm", "Error reading SSH protocol banner", hoac tuong tu
nhu sai mat khau du that ra khong phai. OpenSSH client (lenh `ssh` co san
tren Linux/Mac, hoac Git-Bash/WSL tren Windows) van con cho phep BAT LAI cac
thuat toan cu do qua option `-o`, nen pexpect + spawn lenh `ssh` he thong
thuong "chay duoc" ngay ca khi Paramiko/Netmiko bo tay.

Neu ssh van khong duoc (vi du IOS qua cu, chi ho tro telnet), doi cach spawn
sang: pexpect.spawn(f"telnet {host} {port}") va bo cac buoc "yes/known host"
o duoi.

Cach dung:
    pip install -r ../requirements.txt        # (nen dung venv: python3 -m venv .venv)

    # 0) Credential KHONG nam trong YAML. Sao chep env.example thanh .env roi dien
    #    NETLAB_USERNAME / NETLAB_PASSWORD / NETLAB_ENABLE_PASSWORD (xem muc 'Credential' o duoi).

    # 1) Luon kiem tra lenh sinh ra truoc (khong dung toi thiet bi that):
    python3 deploy_pexpect.py devices.yaml --dry-run

    # 2) Day that len TAT CA thiet bi trong file:
    python3 deploy_pexpect.py devices.yaml

    # 3) Chi day 1-2 thiet bi cu the (test truoc khi day ca lab):
    python3 deploy_pexpect.py devices.yaml --only HCM-SW HN-DMZ

    # 4) Gop nhieu file (neu ban tach lai thanh 2 file switches/routers):
    python3 deploy_pexpect.py devices_switches.yaml devices_routers.yaml

    # 5) Dung o thiet bi loi dau tien (CD dung co nay):
    python3 deploy_pexpect.py devices.yaml --stop-on-error

Exit code: 0 = tat ca OK | 1 = co thiet bi loi | 2 = sai tham so / thieu credential / YAML hong.
Khi co lenh bi thiet bi tu choi, script KHONG chay 'write memory' (startup-config giu nguyen).

# nornir_tasks.py   [THU NGHIEM - khong thuoc pipeline CI/CD]
nornir_tasks.py
----------------
Custom Nornir task: day cau hinh qua pexpect - KHONG dung nornir_netmiko hay
nornir_napalm, vi 2 plugin do chay tren Netmiko/Paramiko va nhieu kha nang
dinh dung van de crypto SSH cu giong nhu o tuan 4.

Task tu tra cuu du lieu cau hinh cua host (trong device_lookup, lay tu chinh
devices_corrected.yaml) roi goi lai dung cac ham da viet + test o tuan 4:
config_builder.build_commands_for_device() va deploy_pexpect.connect/
push_commands/save_and_backup - khong viet lai logic ket noi.

# nornir_push.py   [THU NGHIEM - khong thuoc pipeline CI/CD]
nornir_push.py
---------------
Tuan 5: chay task push_config_pexpect DONG THOI (song song, nhieu thread)
len TAT CA thiet bi khai bao trong inventory/ - thay cho vong lap tuan tu
device-by-device trong deploy_pexpect.py (tuan 4).

Chuan bi (1 lan):
    python3 generate_nornir_inventory.py devices_corrected.yaml -o inventory/

Chay:
    python3 nornir_push.py devices_corrected.yaml --dry-run
    python3 nornir_push.py devices_corrected.yaml --group switches
    python3 nornir_push.py devices_corrected.yaml            # tat ca, song song


# validate.py  (CI)
Kiểm tra OFFLINE `devices.yaml` (không kết nối thiết bị): IP/netmask/wildcard hợp lệ, không trùng IP, ACL/NAT/VLAN
tham chiếu đúng, không để lộ credential trong YAML, và không cấu hình gì có thể làm mất kết nối quản lý
(IP interface hoặc OSPF phủ dải management `172.16.184.0/24`).

    python3 validate.py devices.yaml            # lỗi => exit 1; cảnh báo vẫn exit 0
    python3 validate.py devices.yaml --strict   # cảnh báo cũng làm thất bại

# preflight.py  (CD)
Trước khi deploy: kiểm tra TCP/22 tới mọi thiết bị (song song) rồi đăng nhập SSH + `show clock`.
Nếu EVE-NG chưa bật hoặc một node chưa boot, pipeline dừng sớm và nói rõ thiết bị nào.

    python3 preflight.py devices.yaml [--tcp-only] [--only HN_GW]

# backup.py  (CD)
Sao lưu `show running-config` của từng thiết bị vào `~/netlab-backups/<ngày-giờ>/<thiết-bị>.cfg` (quyền 600) trên máy
chạy runner. KHÔNG đưa lên GitHub (repo public). Giữ 30 bản mới nhất (`--keep`).

    python3 backup.py devices.yaml [--out-dir DIR] [--keep 30]

# verify.py  (CD)
Kiểm thử sau deploy, mọi kỳ vọng được suy ra từ YAML (`topology.py`): interface đúng IP và không bị admin-down,
VLAN tồn tại đúng tên, số láng giềng OSPF FULL đủ, ping được hai đầu mỗi liên kết point-to-point.

    python3 verify.py devices.yaml [--only HN_GW] [--warn-only]

# netlab_common.py / topology.py
Tiện ích dùng chung: đọc credential, lọc lỗi IOS, chuẩn hóa tên interface; suy ra liên kết/láng giềng OSPF từ YAML.

# Credential (.env)
Credential KHÔNG nằm trong YAML hay trong Git. Local: sao chép `env.example` thành `.env` (đã được `.gitignore`)
và điền `NETLAB_USERNAME`, `NETLAB_PASSWORD`, `NETLAB_ENABLE_PASSWORD` (tuỳ chọn, mặc định = password).
Trên CI chúng lấy từ GitHub Environment `lab` (Settings -> Environments -> lab -> Secrets).
Biến môi trường đã export luôn thắng file `.env`.

Log phiên SSH ghi trong `logs/<thiết-bị>.log` (quyền 600) CHỈ gồm dữ liệu thiết bị gửi về, không có mật khẩu.
Thư mục `logs/` đã được `.gitignore`. Xem tổng quan pipeline tại `../docs/CICD.md`.

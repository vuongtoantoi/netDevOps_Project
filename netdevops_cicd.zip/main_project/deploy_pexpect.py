"""deploy_pexpect.py - đẩy cấu hình (sinh bởi config_builder.py) lên thiết bị Cisco IOS qua SSH bằng pexpect.

Vì sao dùng pexpect + lệnh `ssh` của hệ thống thay cho Netmiko/Paramiko: các IOS image lab cũ chỉ hỗ trợ
thuật toán SSH "cũ" (diffie-hellman-group1-sha1, ssh-rsa, cipher CBC...). Paramiko tắt chúng mặc định,
còn OpenSSH client vẫn bật lại được qua `-o` (xem SSH_LEGACY_OPTS).

Credential KHÔNG nằm trong YAML/Git. Đặt qua biến môi trường (hoặc file .env khi chạy local):
    NETLAB_USERNAME, NETLAB_PASSWORD, NETLAB_ENABLE_PASSWORD (tùy chọn, mặc định = NETLAB_PASSWORD)

Cách dùng:
    python3 deploy_pexpect.py devices.yaml --dry-run                  # chỉ sinh lệnh, không chạm thiết bị
    python3 deploy_pexpect.py devices.yaml                            # đẩy lên TẤT CẢ thiết bị
    python3 deploy_pexpect.py devices.yaml --only HCM-SW HN-DMZ       # chỉ 1-2 thiết bị
    python3 deploy_pexpect.py devices.yaml --stop-on-error            # dừng ở thiết bị lỗi đầu tiên (dùng trong CD)

Exit code: 0 = tất cả OK | 1 = có thiết bị lỗi | 2 = sai tham số / thiếu credential / YAML hỏng.
"""
import argparse
import os
import re
import sys

import pexpect

import config_builder as cb
import netlab_common as nc

# Các option ssh để "nói chuyện" được với IOS image cũ. Chỉ là "cho phép thêm", không bắt buộc dùng.
SSH_LEGACY_OPTS = (
    "-o StrictHostKeyChecking=no "
    "-o UserKnownHostsFile=/dev/null "
    "-o ConnectTimeout=10 "
    "-o KexAlgorithms=+diffie-hellman-group1-sha1,diffie-hellman-group14-sha1 "
    "-o HostKeyAlgorithms=+ssh-rsa "
    "-o PubkeyAcceptedAlgorithms=+ssh-rsa "
    "-o Ciphers=+aes128-cbc,3des-cbc"
)

LOGIN_TIMEOUT = 20
CMD_TIMEOUT = 15
SAVE_TIMEOUT = 60
TFTP_TIMEOUT = 60
PROMPT = r"[>#]\s*$"       # user-exec (>) hoặc privileged/config (#)
PRIV_PROMPT = r"#\s*$"     # chỉ privileged/config mode (mọi chế độ config đều kết thúc bằng #)


# ---------------------------------------------------------------------------
# Phiên SSH
# ---------------------------------------------------------------------------

def open_session_log(log_dir, name):
    os.makedirs(log_dir, exist_ok=True)
    path = os.path.join(log_dir, f"{name}.log")
    handle = open(path, "w", encoding="utf-8")
    try:
        os.chmod(path, 0o600)       # log chứa cấu hình thiết bị -> chỉ chủ sở hữu đọc được
    except OSError:
        pass
    return handle


def close_session(child):
    """Đóng phiên ssh và file log. An toàn khi child=None hoặc gọi nhiều lần."""
    if child is None:
        return
    try:
        child.close()
    except Exception:  # noqa: BLE001 - đóng phiên không bao giờ được làm hỏng luồng chính
        pass
    handle = getattr(child, "_netlab_log", None)
    if handle is not None:
        try:
            handle.close()
        except Exception:  # noqa: BLE001
            pass


def _login(child, device):
    """Đăng nhập, vào enable (nếu cần), tắt phân trang. Ném RuntimeError nếu thất bại."""
    host = device["host"]
    port = device.get("port", 22)
    password = device["password"]

    i = child.expect(
        [
            r"(?i)are you sure you want to continue connecting",
            r"(?i)password:",
            r"(?i)connection refused",
            r"(?i)no route to host",
            pexpect.TIMEOUT,
            pexpect.EOF,
        ]
    )
    if i == 0:
        child.sendline("yes")
        i = child.expect([r"(?i)password:", pexpect.TIMEOUT, pexpect.EOF])
        if i != 0:
            raise RuntimeError("không thấy prompt password sau khi accept host key")
    elif i in (2, 3):
        raise RuntimeError(f"không kết nối được tới {host}:{port} (từ chối/không có route)")
    elif i in (4, 5):
        raise RuntimeError("timeout/EOF trước khi thấy prompt password")

    child.sendline(password)
    i = child.expect([PROMPT, r"(?i)password:", pexpect.TIMEOUT, pexpect.EOF])
    if i == 1:
        raise RuntimeError("sai username/password khi đăng nhập SSH")
    if i in (2, 3):
        raise RuntimeError("timeout/EOF sau khi gửi password đăng nhập")

    # Nếu đang ở user-exec (dấu nhắc kết thúc bằng '>'), cần vào enable mode.
    if child.after.strip().endswith(">"):
        child.sendline("enable")
        i = child.expect([r"(?i)password:", PRIV_PROMPT, pexpect.TIMEOUT, pexpect.EOF])
        if i == 0:
            child.sendline(device.get("enable_password") or password)
            i = child.expect([PRIV_PROMPT, pexpect.TIMEOUT, pexpect.EOF])
            if i != 0:
                raise RuntimeError("sai enable password hoặc timeout khi vào enable mode")
        elif i != 1:
            raise RuntimeError("timeout/EOF khi vào enable mode")

    child.sendline("terminal length 0")   # tắt phân trang --More--
    child.expect(PRIV_PROMPT)


def connect(device, log_dir):
    """Mở kết nối SSH bằng pexpect, đăng nhập, vào enable, tắt phân trang."""
    name = device["name"]
    host = device["host"]
    port = device.get("port", 22)
    username = device["username"]

    cmd = f"ssh {SSH_LEGACY_OPTS} -p {port} {username}@{host}"
    child = pexpect.spawn(cmd, timeout=LOGIN_TIMEOUT, encoding="utf-8", codec_errors="replace")
    child._netlab_log = open_session_log(log_dir, name)
    # QUAN TRỌNG: dùng logfile_read (chỉ ghi dữ liệu thiết bị gửi về).
    # Không dùng child.logfile vì nó ghi cả những gì ta gõ => mật khẩu bị lưu plaintext vào log.
    child.logfile_read = child._netlab_log
    try:
        _login(child, device)
    except Exception:
        close_session(child)
        raise
    return child


def run_command(child, command, timeout=CMD_TIMEOUT):
    """Chạy 1 lệnh EXEC (show/ping...), chờ prompt, trả về output (đã bỏ dòng echo lệnh)."""
    child.sendline(command)
    idx = child.expect([PRIV_PROMPT, pexpect.TIMEOUT, pexpect.EOF], timeout=timeout)
    if idx != 0:
        raise RuntimeError(f"timeout/EOF khi chờ kết quả lệnh '{command}'")
    lines = child.before.replace("\r", "").split("\n")
    # PRIV_PROMPT chỉ khớp từ dấu '#', nên đoạn cuối của `before` là phần tên thiết bị của prompt
    # (vd 'HN_GW'), không phải dữ liệu -> bỏ đi. Nếu không, file backup sẽ có thêm 1 dòng rác sau 'end'.
    lines = lines[:-1]
    if lines and command.strip() in lines[0]:
        lines = lines[1:]
    return "\n".join(lines).strip("\n")


# ---------------------------------------------------------------------------
# Đẩy cấu hình
# ---------------------------------------------------------------------------

def push_commands(child, commands, cmd_timeout=None):
    """Vào configure terminal, gửi từng dòng, rồi 'end'.

    Sau MỖI lệnh luôn đọc cho tới prompt tiếp theo rồi mới phân tích output, nên không bị lệch phiên.
    Trả về (errors, warnings): list các tuple (lệnh, thông báo của IOS).
    Lỗi của lệnh 'no ...' (dọn dẹp) chỉ tính là warning vì có thể đối tượng chưa tồn tại.
    """
    timeout = cmd_timeout or CMD_TIMEOUT
    child.sendline("configure terminal")
    child.expect(r"\(config\)#\s*$")

    errors, warnings = [], []
    for line in commands:
        child.sendline(line)
        idx = child.expect([PRIV_PROMPT, pexpect.TIMEOUT, pexpect.EOF], timeout=timeout)
        if idx != 0:
            # Không còn đồng bộ với thiết bị -> dừng hẳn, không đoán mò.
            raise RuntimeError(f"timeout/EOF sau lệnh '{line.strip()}' (dừng để tránh lệch phiên)")
        is_cleanup = line.strip().startswith("no ")
        for message in nc.find_error_lines(child.before):
            (warnings if is_cleanup else errors).append((line.strip(), message))

    child.sendline("end")
    child.expect(PRIV_PROMPT)
    return errors, warnings


def save_config(child):
    """'write memory' và xác nhận có [OK]."""
    child.sendline("write memory")
    idx = child.expect([PRIV_PROMPT, pexpect.TIMEOUT, pexpect.EOF], timeout=SAVE_TIMEOUT)
    if idx != 0:
        raise RuntimeError("timeout/EOF khi 'write memory'")
    if "[ok]" not in child.before.lower():
        tail = child.before.replace("\r", "").strip()[-200:]
        raise RuntimeError(f"'write memory' không báo [OK]: {tail!r}")


def tftp_backup(child, device):
    """Copy running-config lên TFTP nếu YAML bật backup_config. Trả về list cảnh báo (str).

    Lỗi backup không làm hỏng deploy (chỉ cảnh báo) vì cấu hình đã được đẩy và lưu xong.
    """
    warnings = []
    for line in cb.build_backup_commands(device):
        child.sendline(line)
        output = None
        for _ in range(6):   # IOS thường hỏi 2 câu (địa chỉ, tên file) trước khi chạy
            idx = child.expect(
                [
                    r"(?i)address or name of remote host",
                    r"(?i)destination filename",
                    r"(?i)\[confirm\]",
                    PRIV_PROMPT,
                    pexpect.TIMEOUT,
                    pexpect.EOF,
                ],
                timeout=TFTP_TIMEOUT,
            )
            if idx in (0, 1, 2):
                child.sendline("")      # Enter -> dùng giá trị IOS gợi ý
                continue
            if idx == 3:
                output = child.before
            break
        if output is None:
            raise RuntimeError("timeout/EOF khi copy running-config lên TFTP")
        if nc.find_error_lines(output) or not re.search(r"bytes copied|\[OK", output, re.IGNORECASE):
            snippet = output.replace("\r", " ").replace("\n", " ").strip()[-160:]
            warnings.append(f"backup TFTP có vẻ thất bại: {snippet!r}")
    return warnings


def save_and_backup(child, device):
    """Giữ lại tên hàm cũ cho tương thích (nornir_tasks.py trong experimental/)."""
    save_config(child)
    return tftp_backup(child, device)


def deploy_one(device, log_dir, dry_run=False, show_commands=False, cmd_timeout=None):
    """Đẩy cấu hình lên 1 thiết bị. Trả về dict kết quả (status: ok | dry-run | fail)."""
    name = device["name"]
    result = {
        "name": name, "host": device.get("host"), "status": "fail",
        "commands": 0, "errors": [], "warnings": [], "detail": "",
    }
    print(f"\n=== {name} ({device.get('host')}) ===")
    try:
        commands = cb.build_commands_for_device(device)
    except cb.DeviceConfigError as e:
        result["detail"] = f"lỗi dữ liệu YAML: {e}"
        print(f"  !! BỎ QUA - {result['detail']}")
        return result
    result["commands"] = len(commands)

    if dry_run:
        backup = cb.build_backup_commands(device) or "(không bật)"
        print(f"  (dry-run) sẽ gửi {len(commands)} dòng lệnh, backup: {backup}")
        if show_commands:
            for line in commands:
                print(f"    {line}")
        result["status"] = "dry-run"
        return result

    child = None
    try:
        child = connect(device, log_dir)
        errors, warnings = push_commands(child, commands, cmd_timeout)
        result["errors"] = errors
        result["warnings"] = [f"{cmd}: {msg}" for cmd, msg in warnings]
        if errors:
            result["detail"] = f"{len(errors)} lệnh bị thiết bị từ chối - KHÔNG chạy 'write memory'"
            print(f"  !! ĐẨY XONG NHƯNG CÓ {len(errors)} LỆNH BỊ TỪ CHỐI (không lưu startup-config):")
            for cmd, msg in errors:
                print(f"       - {cmd}  =>  {msg}")
            print(f"     (xem chi tiết trong {log_dir}/{name}.log)")
        else:
            save_config(child)
            result["warnings"] += tftp_backup(child, device)
            result["status"] = "ok"
            print(f"  OK - đã đẩy {len(commands)} dòng lệnh và lưu cấu hình. Log: {log_dir}/{name}.log")
            for w in result["warnings"]:
                print(f"  (cảnh báo) {w}")
        child.sendline("exit")
    except Exception as e:  # noqa: BLE001 - bắt hết lỗi kết nối/timeout để còn báo cáo thiết bị tiếp theo
        result["detail"] = f"{type(e).__name__}: {e}"
        print(f"  !! LỖI KHI ĐẨY CẤU HÌNH: {result['detail']}")
        print(f"     (xem chi tiết trong {log_dir}/{name}.log)")
    finally:
        close_session(child)
    return result


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def load_devices(files, only=None):
    """Đọc YAML và lọc theo --only. Ném ValueError nếu tên thiết bị không tồn tại (tránh gõ sai tên mà không biết)."""
    devices = cb.load_all_devices(files)
    if only:
        known = [d["name"] for d in devices]
        unknown = [n for n in only if n not in known]
        if unknown:
            raise ValueError(f"Không có thiết bị tên {unknown}. Thiết bị hợp lệ: {known}")
        devices = [d for d in devices if d["name"] in only]
    return devices


def build_parser():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="+", help="1 hoặc nhiều file YAML thiết bị (vd devices.yaml)")
    ap.add_argument("--only", nargs="*", help="chỉ xử lý các thiết bị có tên này (vd --only HCM-SW HN-DMZ)")
    ap.add_argument("--dry-run", action="store_true", help="chỉ in ra lệnh sẽ gửi, KHÔNG kết nối thiết bị thật")
    ap.add_argument("--show-commands", action="store_true", help="(dry-run) in toàn bộ lệnh sẽ gửi")
    ap.add_argument("--stop-on-error", action="store_true", help="dừng ngay ở thiết bị lỗi đầu tiên")
    ap.add_argument("--log-dir", default="logs", help="thư mục lưu log phiên pexpect (mặc định: logs/)")
    ap.add_argument("--cmd-timeout", type=int, default=None, help=f"timeout mỗi lệnh (giây, mặc định {CMD_TIMEOUT})")
    return ap


def summary_markdown(results, dry_run):
    title = "Kết quả dry-run" if dry_run else "Kết quả deploy"
    rows = [f"### {title}", "", "| Thiết bị | IP | Trạng thái | Số lệnh | Ghi chú |", "|---|---|---|---|---|"]
    icon = {"ok": "✅ ok", "dry-run": "🧪 dry-run", "fail": "❌ lỗi", "skipped": "⏭️ bỏ qua"}
    for r in results:
        note = r["detail"] or (f"{len(r['warnings'])} cảnh báo" if r["warnings"] else "")
        rows.append(f"| {r['name']} | {r['host']} | {icon.get(r['status'], r['status'])} | {r['commands']} | {note} |")
    return "\n".join(rows)


def main(argv=None):
    args = build_parser().parse_args(argv)
    nc.load_dotenv()

    try:
        devices = load_devices(args.files, args.only)
    except (ValueError, OSError) as e:
        print(f"LỖI: {e}")
        return 2
    except Exception as e:  # noqa: BLE001 - YAML hỏng cú pháp...
        print(f"LỖI khi đọc YAML: {type(e).__name__}: {e}")
        return 2
    if not devices:
        print("Không tìm thấy thiết bị nào khớp điều kiện.")
        return 2

    if not args.dry_run:
        try:
            for d in devices:
                d.update(nc.resolve_credentials(d))
        except nc.CredentialError as e:
            print(f"LỖI: {e}")
            return 2

    results = []
    for index, d in enumerate(devices):
        res = deploy_one(d, args.log_dir, dry_run=args.dry_run,
                         show_commands=args.show_commands, cmd_timeout=args.cmd_timeout)
        results.append(res)
        if res["status"] == "fail" and args.stop_on_error:
            for rest in devices[index + 1:]:
                results.append({"name": rest["name"], "host": rest.get("host"), "status": "skipped",
                                "commands": 0, "errors": [], "warnings": [], "detail": "dừng do --stop-on-error"})
            print("\n!! Dừng do --stop-on-error")
            break

    ok = [r["name"] for r in results if r["status"] in ("ok", "dry-run")]
    fail = [r["name"] for r in results if r["status"] == "fail"]
    skipped = [r["name"] for r in results if r["status"] == "skipped"]
    print(f"\n\nTỔNG KẾT: {len(ok)} OK {ok}\n          {len(fail)} LỖI {fail}"
          + (f"\n          {len(skipped)} BỎ QUA {skipped}" if skipped else ""))
    nc.write_step_summary(summary_markdown(results, args.dry_run))
    for r in results:
        if r["status"] == "fail":
            nc.annotate("error", f"{r['name']}: {r['detail'] or 'có lệnh bị từ chối'}", title="Deploy lỗi")
    return 1 if (fail or skipped) else 0


if __name__ == "__main__":
    sys.exit(main())

"""topology.py - suy ra "ý định" của mạng từ devices.yaml (không kết nối thiết bị).

Dùng chung cho validate.py (kiểm tra logic dữ liệu) và verify.py (kiểm thử sau deploy):
- l3_interfaces(): mọi interface có IP mà config_builder thực sự cấu hình.
- link_peers():    các liên kết point-to-point (/29../31) có đúng 2 thiết bị ở hai đầu.
- expected_ospf_neighbors(): mỗi thiết bị OSPF phải có bao nhiêu láng giềng FULL.
"""
import ipaddress
from collections import defaultdict

import config_builder as cb


def get_ospf(dev):
    """Khối OSPF đang bật của thiết bị (router: 'ospf'; switch L3: 'ip_routing.ospf'), hoặc None."""
    if cb.is_router_schema(dev):
        ospf = dev.get("ospf")
    else:
        routing = dev.get("ip_routing") or {}
        ospf = routing.get("ospf") if routing.get("enabled") else None
    return ospf if (ospf and ospf.get("enabled")) else None


def get_static_routes(dev):
    if cb.is_router_schema(dev):
        return dev.get("static") or []
    routing = dev.get("ip_routing") or {}
    return (routing.get("static") or []) if routing.get("enabled") else []


def _safe_interfaces(dev):
    try:
        return cb.normalize_interfaces(dev)
    except cb.DeviceConfigError:
        return {}


def l3_interfaces(dev):
    """List dict(name, ip, netmask, shutdown, kind) cho mọi interface có IP mà config_builder sẽ cấu hình.

    Với switch, config_builder chỉ cấu hình IP cho SVI (VlanN) trong 'interfaces', nên interface vật lý
    có 'ip' bị bỏ qua - ở đây cũng bỏ qua để khớp với thực tế.
    """
    out = []
    is_router = cb.is_router_schema(dev)
    for name, props in _safe_interfaces(dev).items():
        if not props.get("ip"):
            continue
        svi = cb.is_svi_name(name)
        if is_router or svi:
            out.append({"name": name, "ip": str(props["ip"]), "netmask": props.get("netmask"),
                        "shutdown": bool(props.get("shutdown")), "kind": "svi" if svi else "interface"})
    for item in dev.get("routed_interfaces") or []:
        if isinstance(item, dict) and len(item) == 1:
            (name, props), = item.items()
            if isinstance(props, dict) and props.get("ip"):
                out.append({"name": name, "ip": str(props["ip"]), "netmask": props.get("netmask"),
                            "shutdown": bool(props.get("shutdown")), "kind": "routed"})
    for tun in dev.get("tunnel") or []:
        if isinstance(tun, dict) and tun.get("ip"):
            out.append({"name": tun.get("name", "?"), "ip": str(tun["ip"]), "netmask": tun.get("netmask"),
                        "shutdown": bool(tun.get("shutdown")), "kind": "tunnel"})
    return out


def own_interface_names(dev):
    """Tập tên interface (đã chuẩn hóa) mà thiết bị khai báo trong YAML."""
    from netlab_common import canon_iface
    names = {canon_iface(n) for n in _safe_interfaces(dev)}
    for item in dev.get("routed_interfaces") or []:
        if isinstance(item, dict) and len(item) == 1:
            names.add(canon_iface(next(iter(item))))
    for tun in dev.get("tunnel") or []:
        if isinstance(tun, dict) and tun.get("name"):
            names.add(canon_iface(tun["name"]))
    return names


def wildcard_to_network(network, wildcard):
    """OSPF 'network A.B.C.D W.W.W.W' -> IPv4Network. Ném ValueError nếu wildcard không liền khối."""
    w = int(ipaddress.IPv4Address(str(wildcard)))
    if w & (w + 1):
        raise ValueError(f"wildcard '{wildcard}' không phải wildcard hợp lệ (phải là các bit 1 liền nhau từ phải sang)")
    prefix = 32 - w.bit_length()
    addr = int(ipaddress.IPv4Address(str(network))) & ~w & 0xFFFFFFFF
    return ipaddress.IPv4Network((addr, prefix))


def ospf_networks(dev):
    """Danh sách IPv4Network trong các câu lệnh 'network' của OSPF (bỏ qua câu sai cú pháp)."""
    ospf = get_ospf(dev)
    nets = []
    for entry in (ospf or {}).get("networks", []) or []:
        try:
            nets.append(wildcard_to_network(entry["network"], entry["wildcard"]))
        except (KeyError, ValueError):
            continue
    return nets


def ospf_covers(dev, ip):
    addr = ipaddress.IPv4Address(str(ip))
    return any(addr in net for net in ospf_networks(dev))


def link_peers(devices):
    """Các liên kết point-to-point: list cặp ((tên, ip, interface), (tên, ip, interface)).

    Chỉ xét mạng /29../31 có đúng 2 thiết bị khác nhau, bỏ qua interface đang shutdown.
    """
    by_net = defaultdict(list)
    for dev in devices:
        for itf in l3_interfaces(dev):
            if itf["shutdown"]:
                continue
            try:
                ifc = ipaddress.ip_interface(f"{itf['ip']}/{itf['netmask']}")
            except ValueError:
                continue
            if 29 <= ifc.network.prefixlen <= 31:
                by_net[ifc.network].append((dev["name"], str(ifc.ip), itf["name"]))
    pairs = []
    for members in by_net.values():
        if len(members) == 2 and members[0][0] != members[1][0]:
            pairs.append((members[0], members[1]))
    return pairs


def expected_ospf_neighbors(devices):
    """{tên thiết bị: số láng giềng OSPF FULL kỳ vọng}, chỉ gồm thiết bị bật OSPF.

    Một láng giềng được kỳ vọng khi 2 đầu của 1 liên kết point-to-point đều bật OSPF và
    đều có câu lệnh 'network' phủ IP của interface đó.
    """
    by_name = {d["name"]: d for d in devices}
    expected = {d["name"]: 0 for d in devices if get_ospf(d)}
    for a, b in link_peers(devices):
        da, db = by_name[a[0]], by_name[b[0]]
        if get_ospf(da) and get_ospf(db) and ospf_covers(da, a[1]) and ospf_covers(db, b[1]):
            expected[a[0]] += 1
            expected[b[0]] += 1
    return expected

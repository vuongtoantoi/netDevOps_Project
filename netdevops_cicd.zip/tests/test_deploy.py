import contextlib
import io
import os
import tempfile
import unittest
from unittest import mock

import _fakes
from _fakes import FakeIOS, FakeLab

import pexpect

import config_builder as cb
import deploy_pexpect as dp
import netlab_common as nc

PASSWORD = "s3cret-Pw!"


def device(**extra):
    base = {"name": "R1", "host": "10.0.0.1", "port": 22, "username": "admin",
            "password": PASSWORD, "enable_password": PASSWORD}
    base.update(extra)
    return base


class Base(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.tmp = tmp.name
        self.log_dir = os.path.join(self.tmp, "logs")

    def use(self, **ios_by_ip):
        lab = FakeLab({ip.replace("_", "."): d for ip, d in ios_by_ip.items()})
        patcher = mock.patch.object(pexpect, "spawn", lab.spawn)
        patcher.start()
        self.addCleanup(patcher.stop)
        return lab

    def read_log(self, name="R1"):
        with open(os.path.join(self.log_dir, f"{name}.log"), encoding="utf-8") as fh:
            return fh.read()


class ConnectTests(Base):
    def test_mat_khau_khong_bi_ghi_vao_log(self):
        """Hồi quy: bản cũ dùng child.logfile nên MẬT KHẨU bị lưu plaintext vào logs/*.log."""
        self.use(**{"10_0_0_1": FakeIOS("R1", password=PASSWORD)})
        child = dp.connect(device(), self.log_dir)
        self.assertIsNone(child.logfile)
        dp.run_command(child, "terminal length 0")
        dp.close_session(child)
        log = self.read_log()
        self.assertNotIn(PASSWORD, log)
        self.assertIn("R1#", log)             # vẫn log được output của thiết bị

    def test_log_chi_chu_so_huu_doc_duoc(self):
        self.use(**{"10_0_0_1": FakeIOS("R1", password=PASSWORD)})
        dp.close_session(dp.connect(device(), self.log_dir))
        mode = os.stat(os.path.join(self.log_dir, "R1.log")).st_mode & 0o777
        self.assertEqual(mode, 0o600)

    def test_ssh_dung_option_cho_image_cu_va_connect_timeout(self):
        lab = self.use(**{"10_0_0_1": FakeIOS("R1", password=PASSWORD)})
        dp.close_session(dp.connect(device(), self.log_dir))
        cmd = lab.commands[0]
        self.assertIn("diffie-hellman-group1-sha1", cmd)
        self.assertIn("ConnectTimeout=10", cmd)
        self.assertTrue(cmd.endswith("-p 22 admin@10.0.0.1"))

    def test_dang_nhap_vao_user_exec_se_enable(self):
        ios = FakeIOS("R1", password=PASSWORD, user_mode=True, enable_password="en4ble")
        self.use(**{"10_0_0_1": ios})
        dp.close_session(dp.connect(device(enable_password="en4ble"), self.log_dir))
        self.assertTrue(ios.enabled)
        self.assertNotIn("en4ble", self.read_log())

    def test_sai_mat_khau(self):
        self.use(**{"10_0_0_1": FakeIOS("R1", password="dung")})
        with self.assertRaises(RuntimeError) as ctx:
            dp.connect(device(password="sai"), self.log_dir)
        self.assertIn("sai username/password", str(ctx.exception))

    def test_ket_noi_bi_tu_choi(self):
        self.use()
        with self.assertRaises(RuntimeError) as ctx:
            dp.connect(device(host="10.9.9.9"), self.log_dir)
        self.assertIn("không kết nối được", str(ctx.exception))


class PushCommandTests(Base):
    def connect(self, ios):
        self.use(**{"10_0_0_1": ios})
        child = dp.connect(device(), self.log_dir)
        self.addCleanup(dp.close_session, child)
        return child

    def test_bat_lenh_bi_tu_choi(self):
        ios = FakeIOS("R1", password=PASSWORD, errors={"bad cmd": "% Invalid input detected at '^' marker."})
        errors, warnings = dp.push_commands(self.connect(ios), ["interface e0/0", " no shutdown", "bad cmd", "exit"])
        self.assertEqual(errors, [("bad cmd", "% Invalid input detected at '^' marker.")])
        self.assertEqual(warnings, [])
        self.assertEqual(ios.mode, "exec")

    def test_khong_lech_phien_sau_loi(self):
        """Hồi quy: bản cũ để sót prompt trong buffer sau lỗi nên các lệnh sau bị gán sai phản hồi."""
        ios = FakeIOS("R1", password=PASSWORD, errors={"c2": "% E2", "c4": "% E4"})
        errors, _ = dp.push_commands(self.connect(ios), ["c1", "c2", "c3", "c4", "c5"])
        self.assertEqual(errors, [("c2", "% E2"), ("c4", "% E4")])

    def test_duplicate_sequence_la_loi_that(self):
        ios = FakeIOS("R1", password=PASSWORD, errors={"10 permit ip any any": "% Duplicate sequence number"})
        errors, _ = dp.push_commands(self.connect(ios), ["ip access-list extended X", " 10 permit ip any any"])
        self.assertEqual(errors, [("10 permit ip any any", "% Duplicate sequence number")])

    def test_loi_cua_lenh_no_chi_la_canh_bao(self):
        ios = FakeIOS("R1", password=PASSWORD, errors={"no ip access-list extended X": "% Invalid input detected"})
        errors, warnings = dp.push_commands(self.connect(ios), ["no ip access-list extended X"])
        self.assertEqual(errors, [])
        self.assertEqual(len(warnings), 1)

    def test_canh_bao_portfast_khong_bi_coi_la_loi(self):
        portfast = ("%Warning: portfast should only be enabled on ports connected to a single\r\n"
                    " host. Use with CAUTION\r\n"
                    "%Portfast has been configured on Ethernet0/1 but will only\r\n"
                    " have effect when the interface is in a non-trunking mode.")
        ios = FakeIOS("R1", password=PASSWORD, errors={"spanning-tree portfast": portfast})
        errors, warnings = dp.push_commands(self.connect(ios), ["interface e0/1", " spanning-tree portfast"])
        self.assertEqual((errors, warnings), ([], []))

    def test_timeout_giua_phien_thi_dung_han(self):
        ios = FakeIOS("R1", password=PASSWORD, hang_on="ip route 1.1.1.1 255.255.255.255 2.2.2.2")
        child = self.connect(ios)
        with self.assertRaises(RuntimeError) as ctx:
            dp.push_commands(child, ["hostname R1", "ip route 1.1.1.1 255.255.255.255 2.2.2.2", "hostname NEVER"])
        self.assertIn("timeout", str(ctx.exception))
        self.assertNotIn("hostname NEVER", ios.applied)       # không gửi tiếp khi đã lệch phiên


class SaveAndBackupTests(Base):
    def connect(self, ios):
        self.use(**{"10_0_0_1": ios})
        child = dp.connect(device(), self.log_dir)
        self.addCleanup(dp.close_session, child)
        return child

    def test_write_memory_ok(self):
        ios = FakeIOS("R1", password=PASSWORD)
        dp.save_config(self.connect(ios))
        self.assertTrue(ios.saved)

    def test_write_memory_that_bai_nem_loi(self):
        with self.assertRaises(RuntimeError) as ctx:
            dp.save_config(self.connect(FakeIOS("R1", password=PASSWORD, write_ok=False)))
        self.assertIn("không báo [OK]", str(ctx.exception))

    def test_tftp_backup_thanh_cong(self):
        ios = FakeIOS("R1", password=PASSWORD)
        dev = device(tftp={"server": "172.16.184.128", "backup_config": True})
        self.assertEqual(dp.tftp_backup(self.connect(ios), dev), [])
        self.assertIn("copy running-config tftp://172.16.184.128/R1-running.cfg", ios.received)
        self.assertEqual(ios.received.count(""), 2)          # đã Enter qua 2 câu hỏi của IOS

    def test_tftp_that_bai_chi_canh_bao(self):
        ios = FakeIOS("R1", password=PASSWORD, tftp_ok=False)
        dev = device(tftp={"server": "172.16.184.128", "backup_config": True})
        warnings = dp.tftp_backup(self.connect(ios), dev)
        self.assertEqual(len(warnings), 1)
        self.assertIn("thất bại", warnings[0])

    def test_khong_bat_backup_thi_khong_lam_gi(self):
        ios = FakeIOS("R1", password=PASSWORD)
        self.assertEqual(dp.tftp_backup(self.connect(ios), device()), [])
        self.assertNotIn("copy running-config", " ".join(ios.received))

    def test_phien_van_dong_bo_sau_write_memory_va_tftp(self):
        """Hồi quy: log thật cho thấy lệnh 'copy ... tftp' bị gửi 'exit' ngay sau đó vì buffer còn prompt cũ."""
        ios = FakeIOS("R1", password=PASSWORD, show={"show clock": "10:00:00.000 UTC Wed Oct 7 2026"})
        child = self.connect(ios)
        dev = device(tftp={"server": "172.16.184.128", "backup_config": True})
        dp.save_config(child)
        dp.tftp_backup(child, dev)
        self.assertEqual(dp.run_command(child, "show clock"), "10:00:00.000 UTC Wed Oct 7 2026")
        self.assertNotIn("exit", ios.received)


class DeployOneTests(Base):
    def test_thanh_cong_luu_cau_hinh_va_khong_lo_mat_khau(self):
        ios = FakeIOS("R1", password=PASSWORD)
        self.use(**{"10_0_0_1": ios})
        dev = device(interfaces=[{"e0/0": {"ip": "10.1.1.1", "netmask": "255.255.255.0", "shutdown": False}}],
                     protocol="ssh")
        result = dp.deploy_one(dev, self.log_dir)
        self.assertEqual(result["status"], "ok", result)
        self.assertTrue(ios.saved)
        self.assertIn("hostname R1", ios.applied)
        self.assertIn("ip address 10.1.1.1 255.255.255.0", ios.applied)
        self.assertNotIn(PASSWORD, self.read_log())

    def test_co_lenh_bi_tu_choi_thi_khong_luu_startup_config(self):
        ios = FakeIOS("R1", password=PASSWORD, errors={"hostname R1": "% Invalid input detected at '^' marker."})
        self.use(**{"10_0_0_1": ios})
        result = dp.deploy_one(device(protocol="ssh"), self.log_dir)
        self.assertEqual(result["status"], "fail")
        self.assertFalse(ios.saved)
        self.assertIn("KHÔNG chạy 'write memory'", result["detail"])

    def test_timeout_la_that_bai_va_khong_luu(self):
        ios = FakeIOS("R1", password=PASSWORD, hang_on="hostname R1")
        self.use(**{"10_0_0_1": ios})
        result = dp.deploy_one(device(protocol="ssh"), self.log_dir)
        self.assertEqual(result["status"], "fail")
        self.assertFalse(ios.saved)
        self.assertIn("RuntimeError", result["detail"])

    def test_khong_ket_noi_duoc(self):
        self.use()
        result = dp.deploy_one(device(host="10.9.9.9", protocol="ssh"), self.log_dir)
        self.assertEqual(result["status"], "fail")

    def test_du_lieu_yaml_loi_thi_bo_qua_thiet_bi(self):
        self.use()
        bad = {"name": "SWX", "host": "10.0.0.9", "type": "cisco_ios", "vlans": {-10: "IT"}}
        result = dp.deploy_one(bad, self.log_dir)
        self.assertEqual(result["status"], "fail")
        self.assertIn("lỗi dữ liệu YAML", result["detail"])

    def test_dry_run_khong_mo_ket_noi(self):
        with mock.patch.object(pexpect, "spawn", side_effect=AssertionError("dry-run không được kết nối")):
            result = dp.deploy_one(device(protocol="ssh"), self.log_dir, dry_run=True)
        self.assertEqual(result["status"], "dry-run")


class MainCliTests(Base):
    def setUp(self):
        super().setUp()
        self.yaml = os.path.join(self.tmp, "devices.yaml")
        with open(self.yaml, "w", encoding="utf-8") as fh:
            fh.write(_fakes.sample_yaml())
        patcher = mock.patch.object(nc, "load_dotenv", return_value=False)   # không đọc .env thật của máy dev
        patcher.start()
        self.addCleanup(patcher.stop)

    def run_main(self, argv, env=None):
        env = {"NETLAB_USERNAME": "admin", "NETLAB_PASSWORD": PASSWORD} if env is None else env
        buf = io.StringIO()
        with mock.patch.dict(os.environ, env, clear=True), contextlib.redirect_stdout(buf):
            code = dp.main([self.yaml, "--log-dir", self.log_dir] + argv)
        return code, buf.getvalue()

    def test_deploy_thanh_cong_exit_0(self):
        r1, sw1 = FakeIOS("R1", password=PASSWORD), FakeIOS("SW1", password=PASSWORD)
        self.use(**{"10_0_0_1": r1, "10_0_0_2": sw1})
        code, out = self.run_main([])
        self.assertEqual(code, 0, out)
        self.assertTrue(r1.saved and sw1.saved)
        self.assertIn("vlan 10", sw1.applied)
        for name in ("R1", "SW1"):
            self.assertNotIn(PASSWORD, self.read_log(name))

    def test_co_thiet_bi_loi_exit_1(self):
        self.use(**{"10_0_0_1": FakeIOS("R1", password=PASSWORD)})        # SW1 không tồn tại -> từ chối kết nối
        code, out = self.run_main([])
        self.assertEqual(code, 1, out)
        self.assertIn("SW1", out)

    def test_stop_on_error_bo_qua_thiet_bi_con_lai(self):
        sw1 = FakeIOS("SW1", password=PASSWORD)
        self.use(**{"10_0_0_2": sw1})                                       # R1 lỗi trước
        code, out = self.run_main(["--stop-on-error"])
        self.assertEqual(code, 1)
        self.assertIn("BỎ QUA", out)
        self.assertFalse(sw1.saved)
        self.assertEqual(sw1.received, [])                                  # chưa hề kết nối SW1

    def test_thieu_credential_exit_2_va_khong_mo_ket_noi(self):
        with mock.patch.object(pexpect, "spawn", side_effect=AssertionError("không được kết nối")):
            code, out = self.run_main([], env={})
        self.assertEqual(code, 2)
        self.assertIn("NETLAB_PASSWORD", out)

    def test_dry_run_khong_can_credential(self):
        with mock.patch.object(pexpect, "spawn", side_effect=AssertionError("không được kết nối")):
            code, out = self.run_main(["--dry-run", "--show-commands"], env={})
        self.assertEqual(code, 0, out)
        self.assertIn("hostname R1", out)

    def test_gõ_sai_ten_only_exit_2(self):
        code, out = self.run_main(["--only", "R99"])
        self.assertEqual(code, 2)
        self.assertIn("Thiết bị hợp lệ", out)

    def test_only_loc_dung_thiet_bi(self):
        r1, sw1 = FakeIOS("R1", password=PASSWORD), FakeIOS("SW1", password=PASSWORD)
        self.use(**{"10_0_0_1": r1, "10_0_0_2": sw1})
        code, _ = self.run_main(["--only", "SW1"])
        self.assertEqual(code, 0)
        self.assertEqual(r1.received, [])

    def test_yaml_hong_exit_2(self):
        with open(self.yaml, "w", encoding="utf-8") as fh:
            fh.write("devices: [unclosed")
        code, out = self.run_main(["--dry-run"], env={})
        self.assertEqual(code, 2)

    def test_summary_markdown(self):
        results = [{"name": "R1", "host": "10.0.0.1", "status": "ok", "commands": 5, "errors": [],
                    "warnings": ["x"], "detail": ""},
                   {"name": "SW1", "host": "10.0.0.2", "status": "fail", "commands": 3, "errors": [],
                    "warnings": [], "detail": "lỗi"}]
        md = dp.summary_markdown(results, dry_run=False)
        self.assertIn("| R1 | 10.0.0.1 | ✅ ok | 5 | 1 cảnh báo |", md)
        self.assertIn("| SW1 | 10.0.0.2 | ❌ lỗi | 3 | lỗi |", md)


class LoadDevicesTests(unittest.TestCase):
    def test_only_sai_ten_nem_loi_liet_ke_ten_hop_le(self):
        with self.assertRaises(ValueError) as ctx:
            dp.load_devices([_fakes.DEVICES_YAML], only=["HN_GW", "KHONG_CO"])
        self.assertIn("KHONG_CO", str(ctx.exception))
        self.assertIn("HCM_GW", str(ctx.exception))

    def test_loc_theo_only(self):
        devices = dp.load_devices([_fakes.DEVICES_YAML], only=["HN_GW"])
        self.assertEqual([d["name"] for d in devices], ["HN_GW"])
        self.assertEqual(len(dp.load_devices([_fakes.DEVICES_YAML])), 10)

    def test_ten_thiet_bi_that_deu_sinh_lenh(self):
        for d in dp.load_devices([_fakes.DEVICES_YAML]):
            self.assertTrue(cb.build_commands_for_device(d))


if __name__ == "__main__":
    unittest.main()

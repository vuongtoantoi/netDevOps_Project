"""Công cụ dùng chung cho test: đưa main_project vào sys.path, giả lập pexpect + thiết bị Cisco IOS.

Test chạy OFFLINE (không cần EVE-NG, không cần pexpect thật). FakeChild mô phỏng cách pexpect khớp pattern:
pattern khớp SỚM NHẤT trong buffer thắng; phần buffer đến hết chỗ khớp bị "tiêu thụ"; .before/.after
được gán đúng như pexpect thật. Nhờ vậy các lỗi kiểu "prompt cũ còn sót trong buffer" cũng tái hiện được.
"""
import os
import re
import sys
import types

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAIN = os.path.join(ROOT, "main_project")
DEVICES_YAML = os.path.join(MAIN, "devices.yaml")
if MAIN not in sys.path:
    sys.path.insert(0, MAIN)

try:
    import pexpect  # noqa: F401
except ImportError:  # môi trường không có pexpect: tạo stub tối thiểu (chỉ để import được)
    _stub = types.ModuleType("pexpect")

    class _TIMEOUT(Exception):
        pass

    class _EOF(Exception):
        pass

    _stub.TIMEOUT, _stub.EOF, _stub.spawn = _TIMEOUT, _EOF, None
    sys.modules["pexpect"] = _stub
    import pexpect  # noqa: F401,E402


class FakeIOS:
    """Một thiết bị Cisco IOS giả: login bằng password, mode exec/config, lỗi tiêm theo lệnh."""

    SUBMODES = (
        ("interface ", "if"), ("router ", "router"), ("ip access-list standard", "std-nacl"),
        ("ip access-list extended", "ext-nacl"), ("vlan ", "vlan"), ("ip dhcp pool", "dhcp-config"),
    )

    def __init__(self, hostname="R1", password="s3cret", errors=None, show=None,
                 tftp_ok=True, user_mode=False, hang_on=None, write_ok=True, enable_password=None):
        self.hostname = hostname
        self.password = password
        self.enable_password = enable_password
        self.errors = errors or {}        # lệnh (đã strip) -> text lỗi in ra sau echo
        self.show = show or {}            # lệnh exec -> output
        self.tftp_ok = tftp_ok
        self.user_mode = user_mode        # đăng nhập vào '>' (cần enable)
        self.hang_on = hang_on            # lệnh khiến thiết bị "treo" (không trả prompt)
        self.write_ok = write_ok
        self.mode = "login"
        self.stack = []
        self.pending = None
        self.eof = False
        self.received = []                # mọi dòng thiết bị nhận được
        self.applied = []                 # các dòng config đã nhận ở config mode
        self.saved = False
        self.refuse = False

    def greeting(self):
        if self.refuse:
            self.eof = True
            return "ssh: connect to host 10.9.9.9 port 22: Connection refused\r\n"
        return "(admin@10.0.0.1) Password: "

    def prompt(self):
        if self.mode == "exec":
            return f"{self.hostname}>" if (self.user_mode and not self.enabled) else f"{self.hostname}#"
        if self.mode == "enable-pw":
            return ""
        sub = f"-{self.stack[-1]}" if self.stack else ""
        return f"{self.hostname}(config{sub})#"

    enabled = False

    def handle(self, line):
        self.received.append(line)
        text = line.strip()
        if self.mode == "login":
            if line == self.password:
                self.mode = "exec"
                return f"\r\n\r\n{self.prompt()}"
            return "\r\nPassword: "
        if self.mode == "enable-pw":
            if line == (self.enable_password or self.password):
                self.mode, self.enabled = "exec", True
                return f"\r\n{self.prompt()}"
            self.mode = "exec"
            return f"\r\n% Access denied\r\n{self.prompt()}"
        if self.pending is not None:
            return self._tftp_step()

        echo = f"{line}\r\n"
        if self.hang_on is not None and text == self.hang_on:
            return echo                                   # không trả prompt -> client timeout
        if self.mode == "exec":
            return echo + self._exec(text)
        return echo + self._config(line, text)

    # -- exec mode ---------------------------------------------------------
    def _exec(self, text):
        if text == "enable" and self.user_mode and not self.enabled:
            self.mode = "enable-pw"
            return "Password: "
        if text == "terminal length 0":
            return self.prompt()
        if text == "configure terminal":
            self.mode, self.stack = "config", []
            return f"Enter configuration commands, one per line.  End with CNTL/Z.\r\n{self.prompt()}"
        if text == "write memory":
            if self.write_ok:
                self.saved = True
                return f"Building configuration...\r\n[OK]\r\n{self.prompt()}"
            return f"Building configuration...\r\n[FAILED]\r\n{self.prompt()}"
        if text.startswith("copy running-config tftp://"):
            self.pending = 1
            return "Address or name of remote host [172.16.184.128]? "
        if text == "exit":
            self.eof = True
            return ""
        if text in self.show:
            return f"{self.show[text]}\r\n{self.prompt()}"
        if text.startswith("ping "):
            return ("Type escape sequence to abort.\r\nSending 5, 100-byte ICMP Echos, timeout is 2 seconds:\r\n"
                    f"!!!!!\r\nSuccess rate is 100 percent (5/5), round-trip min/avg/max = 1/2/4 ms\r\n{self.prompt()}")
        return f"% Invalid input detected at '^' marker.\r\n{self.prompt()}"

    def _tftp_step(self):
        if self.pending == 1:
            self.pending = 2
            return "Destination filename [R1-running.cfg]? "
        self.pending = None
        if self.tftp_ok:
            return f"!!\r\n3171 bytes copied in 0.320 secs (9909 bytes/sec)\r\n{self.prompt()}"
        return f"%Error opening tftp://172.16.184.128/R1-running.cfg (Timed out)\r\n{self.prompt()}"

    # -- config mode -------------------------------------------------------
    def _config(self, line, text):
        if text == "end":
            self.mode, self.stack = "exec", []
            return self.prompt()
        if text == "exit":
            if self.stack:
                self.stack.pop()
            else:
                self.mode = "exec"
            return self.prompt()
        self.applied.append(text)
        if text in self.errors:
            return f"{self.errors[text]}\r\n{self.prompt()}"
        if text.startswith("hostname "):
            self.hostname = text.split(None, 1)[1]
            return self.prompt()
        if not line.startswith(" "):
            for prefix, name in self.SUBMODES:
                if text.startswith(prefix):
                    self.stack.append(name)
                    break
        return self.prompt()


class FakeChild:
    """Mô phỏng pexpect.spawn: buffer, expect() kiểu 'khớp sớm nhất', logfile / logfile_read."""

    def __init__(self, device):
        self.device = device
        self.before = ""
        self.after = ""
        self.logfile = None
        self.logfile_read = None
        self.closed = False
        self.buffer = ""
        self._append(device.greeting())

    def _append(self, text):
        self.buffer += text
        for sink in (self.logfile_read, self.logfile):
            if sink is not None:
                sink.write(text)

    def sendline(self, line=""):
        if self.logfile is not None:           # child.logfile ghi cả dữ liệu GỬI ĐI (kể cả mật khẩu)
            self.logfile.write(line + "\n")
        self._append(self.device.handle(line))

    def expect(self, patterns, timeout=None):
        pats = patterns if isinstance(patterns, list) else [patterns]
        best = None
        for idx, pat in enumerate(pats):
            if pat is pexpect.TIMEOUT or pat is pexpect.EOF:
                continue
            match = re.compile(pat, re.DOTALL).search(self.buffer)
            if match and (best is None or match.start() < best[1].start()):
                best = (idx, match)
        if best is not None:
            idx, match = best
            self.before, self.after = self.buffer[:match.start()], match.group(0)
            self.buffer = self.buffer[match.end():]
            return idx
        self.before = self.buffer
        if self.device.eof and pexpect.EOF in pats:
            return pats.index(pexpect.EOF)
        if pexpect.TIMEOUT in pats:
            return pats.index(pexpect.TIMEOUT)
        raise pexpect.TIMEOUT("fake timeout")

    def close(self, force=True):
        self.closed = True


class FakeLab:
    """Nhiều thiết bị giả, định tuyến theo IP trong lệnh ssh. Dùng: mock.patch.object(pexpect, 'spawn', lab.spawn)."""

    def __init__(self, devices):
        self.devices = devices            # {ip: FakeIOS}
        self.spawned = []
        self.commands = []

    def spawn(self, cmd, timeout=None, encoding=None, **kwargs):
        self.commands.append(cmd)
        match = re.search(r"-p (\d+) (\S+)@(\S+)$", cmd)
        host = match.group(3)
        device = self.devices.get(host)
        if device is None:
            device = FakeIOS()
            device.refuse = True
        child = FakeChild(device)
        self.spawned.append(child)
        return child


def sample_yaml(extra_devices=""):
    """YAML tối giản (1 router + 1 switch) không chứa credential, dùng cho test CLI."""
    return f"""devices:
  - name: R1
    host: 10.0.0.1
    username: admin
    protocol: ssh
    port: 22
    interfaces:
      - e0/0:
          description: "to SW1"
          ip: 10.1.1.1
          netmask: 255.255.255.0
          shutdown: false
  - name: SW1
    host: 10.0.0.2
    username: admin
    type: cisco_ios
    port: 22
    vlans:
      - 10: Servers
    interfaces:
      - e0/1:
          switchport_mode: access
          switchport_access_vlan: 10
{extra_devices}"""

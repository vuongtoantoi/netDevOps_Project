import contextlib
import io
import os
import socket
import tempfile
import unittest
from unittest import mock

import _fakes
from _fakes import FakeIOS, FakeLab

import pexpect

import backup as bk
import config_builder as cb
import netlab_common as nc
import preflight as pre
import topology as tp
import verify as vf

PASSWORD = "s3cret-Pw!"
DISPLAY = {"ethernet": "Ethernet", "fastethernet": "FastEthernet", "vlan": "Vlan",
           "tunnel": "Tunnel", "port-channel": "Port-channel"}


def full_name(name):
    canon = nc.canon_iface(name)
    for key, shown in DISPLAY.items():
        if canon.startswith(key):
            return shown + canon[len(key):]
    return canon


def brief_output(dev, status="up", protocol="up", skip=None, override_ip=None):
    """Sinh 'show ip interface brief' giống IOS thật cho các interface L3 trong YAML."""
    rows = ["Interface                  IP-Address      OK? Method Status                Protocol"]
    for itf in tp.l3_interfaces(dev):
        if itf["name"] == skip:
            continue
        ip = override_ip if override_ip and itf["name"] == override_ip[0] else itf["ip"]
        rows.append(f"{full_name(itf['name']):<26} {ip:<15} YES manual {status:<21} {protocol}")
    rows.append("Ethernet1/1                172.16.184.12   YES manual up                    up")
    rows.append("Ethernet1/2                unassigned      YES unset  up                    up")
    return "\n".join(rows)


def ospf_output(states):
    rows = ["Neighbor ID     Pri   State           Dead Time   Address         Interface"]
    for i, state in enumerate(states, 1):
        rows.append(f"10.255.0.{i}        1   {state:<15} 00:00:33    10.0.255.{i}      FastEthernet2/0")
    return "\n".join(rows)


def vlan_output(vlans):
    rows = ["VLAN Name                             Status    Ports",
            "---- -------------------------------- --------- ----",
            "1    default                          active    Et0/0, Et0/1"]
    rows += [f"{vid:<4} {name:<32} active    Et0/2" for vid, name in vlans.items()]
    rows.append("1002 fddi-default                     act/unsup")
    return "\n".join(rows)


def make_runner(table):
    def run(command, timeout):
        if command in table:
            return table[command]
        if command.startswith("ping "):
            return "Success rate is 100 percent (5/5), round-trip min/avg/max = 1/2/4 ms"
        raise AssertionError(f"lệnh không mong đợi: {command}")
    return run


class ParserTests(unittest.TestCase):
    def test_ip_interface_brief_ho_tro_status_hai_tu(self):
        hn_gw = next(d for d in cb.load_all_devices([_fakes.DEVICES_YAML]) if d["name"] == "HN_GW")
        text = brief_output(hn_gw, status="administratively down", protocol="down")
        table = vf.parse_ip_interface_brief(text)
        row = table[nc.canon_iface("fa0/0")]
        self.assertEqual((row["ip"], row["status"], row["protocol"]), ("172.16.11.1", "administratively down", "down"))
        self.assertEqual(table[nc.canon_iface("Ethernet1/2")]["ip"], "unassigned")

    def test_vlan_brief(self):
        parsed = vf.parse_vlan_brief(vlan_output({210: "IT", 220: "ACC"}))
        self.assertEqual(parsed[210], {"name": "IT", "status": "active"})
        self.assertEqual(parsed[1002]["status"], "act/unsup")

    def test_ospf_neighbors_dinh_dang_that_cua_ios(self):
        text = ("Neighbor ID     Pri   State           Dead Time   Address         Interface\n"
                "10.0.255.9        1   FULL/DR         00:00:33    10.0.255.1      FastEthernet2/0\n"
                "10.0.255.10       0   FULL/  -        00:00:38    10.0.255.5      Serial3/0\n"
                "10.0.255.11       1   INIT/DROTHER    00:00:31    10.0.255.9      FastEthernet1/0\n")
        nbrs = vf.parse_ospf_neighbors(text)
        self.assertEqual([n["state"] for n in nbrs], ["FULL", "FULL", "INIT"])
        self.assertEqual(nbrs[1]["role"], "-")
        self.assertEqual(nbrs[0]["iface"], "FastEthernet2/0")

    def test_ospf_neighbors_trang_thai(self):
        nbrs = vf.parse_ospf_neighbors(ospf_output(["FULL/DR", "FULL/BDR", "INIT/DROTHER", "2WAY/DROTHER"]))
        self.assertEqual([n["state"] for n in nbrs], ["FULL", "FULL", "INIT", "2WAY"])

    def test_ping(self):
        self.assertEqual(vf.parse_ping_success("Success rate is 80 percent (4/5)"), 80)
        self.assertIsNone(vf.parse_ping_success("% Invalid input"))


class CheckTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.devices = cb.load_all_devices([_fakes.DEVICES_YAML])
        cls.hn_gw = next(d for d in cls.devices if d["name"] == "HN_GW")
        cls.hcm_sw = next(d for d in cls.devices if d["name"] == "HCM-SW")

    def bad(self, results, level="error"):
        return [r for r in results if not r["ok"] and r["level"] == level]

    def test_interface_dung_tat_ca_pass(self):
        results = vf.check_interfaces(self.hn_gw, vf.parse_ip_interface_brief(brief_output(self.hn_gw)))
        self.assertEqual(len(results), 5)            # 4 interface + tunnel0
        self.assertTrue(all(r["ok"] for r in results), results)

    def test_interface_administratively_down_la_loi(self):
        text = brief_output(self.hn_gw, status="administratively down", protocol="down")
        results = vf.check_interfaces(self.hn_gw, vf.parse_ip_interface_brief(text))
        self.assertEqual(len(self.bad(results)), 5)

    def test_interface_line_protocol_down_chi_la_canh_bao(self):
        text = brief_output(self.hn_gw, protocol="down")
        results = vf.check_interfaces(self.hn_gw, vf.parse_ip_interface_brief(text))
        self.assertEqual(self.bad(results), [])
        self.assertEqual(len(self.bad(results, "warn")), 5)

    def test_interface_thieu_hoac_sai_ip(self):
        results = vf.check_interfaces(self.hn_gw, vf.parse_ip_interface_brief(brief_output(self.hn_gw, skip="fa0/0")))
        self.assertIn("không thấy", self.bad(results)[0]["detail"])
        text = brief_output(self.hn_gw).replace("172.16.11.1 ", "172.16.11.99")
        results = vf.check_interfaces(self.hn_gw, vf.parse_ip_interface_brief(text))
        self.assertIn("172.16.11.99", self.bad(results)[0]["detail"])

    def test_vlan(self):
        good = vf.parse_vlan_brief(vlan_output({210: "IT", 220: "ACC", 250: "Guest"}))
        self.assertTrue(all(r["ok"] for r in vf.check_vlans(self.hcm_sw, good)))
        missing = vf.parse_vlan_brief(vlan_output({210: "IT", 250: "Guest"}))
        self.assertEqual([r["name"] for r in self.bad(vf.check_vlans(self.hcm_sw, missing))], ["vlan 220 (ACC)"])
        renamed = vf.parse_vlan_brief(vlan_output({210: "IT", 220: "WRONG", 250: "Guest"}))
        self.assertIn("WRONG", self.bad(vf.check_vlans(self.hcm_sw, renamed))[0]["detail"])

    def test_ospf(self):
        both_full = vf.parse_ospf_neighbors(ospf_output(["FULL/DR", "FULL/BDR"]))
        self.assertTrue(all(r["ok"] for r in vf.check_ospf(both_full, 2)))
        results = vf.check_ospf(vf.parse_ospf_neighbors(ospf_output(["FULL/DR", "INIT/DROTHER"])), 2)
        self.assertEqual(len(self.bad(results)), 1)
        self.assertEqual(len(self.bad(results, "warn")), 1)
        none = vf.check_ospf([], 2)
        self.assertIn("không có láng giềng", none[0]["detail"])
        self.assertTrue(vf.check_ospf([], 0)[0]["ok"])

    def test_ping(self):
        self.assertTrue(vf.check_ping("1.1.1.1", "Success rate is 100 percent (5/5)")["ok"])
        self.assertTrue(vf.check_ping("1.1.1.1", "Success rate is 60 percent (3/5)")["ok"])
        self.assertFalse(vf.check_ping("1.1.1.1", "Success rate is 40 percent (2/5)")["ok"])
        self.assertFalse(vf.check_ping("1.1.1.1", "Success rate is 0 percent (0/5)")["ok"])
        self.assertFalse(vf.check_ping("1.1.1.1", "% Invalid input detected")["ok"])

    def test_ping_targets_cua_hn_gw_la_4_dau_ben_kia(self):
        targets = vf.ping_targets_by_device(self.devices)
        self.assertEqual(set(targets["HN_GW"]), {"200.0.0.1", "10.0.255.14", "10.0.255.2", "10.0.255.6"})
        self.assertEqual(targets["HCM-SW"], [])

    def test_collect_checks_router_ospf_day_du(self):
        run = make_runner({"show ip interface brief": brief_output(self.hn_gw),
                           "show ip ospf neighbor": ospf_output(["FULL/DR", "FULL/BDR"])})
        results = vf.collect_checks(self.hn_gw, run, 2, vf.ping_targets_by_device(self.devices)["HN_GW"])
        self.assertEqual(len(results), 5 + 1 + 4)     # 5 interface + 1 ospf (đủ FULL) + 4 ping
        self.assertTrue(all(r["ok"] for r in results), [r for r in results if not r["ok"]])

    def test_collect_checks_switch_kiem_tra_vlan_khong_kiem_tra_ospf(self):
        run = make_runner({"show ip interface brief": brief_output(self.hcm_sw),
                           "show vlan brief": vlan_output({210: "IT", 220: "ACC", 250: "Guest"})})
        results = vf.collect_checks(self.hcm_sw, run, None, [])
        self.assertEqual([r["name"] for r in results], ["vlan 210 (IT)", "vlan 220 (ACC)", "vlan 250 (Guest)"])


class VerifyCliTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.tmp = tmp.name
        self.yaml = os.path.join(self.tmp, "devices.yaml")
        with open(self.yaml, "w", encoding="utf-8") as fh:
            fh.write(_fakes.sample_yaml())
        for patcher in (mock.patch.object(nc, "load_dotenv", return_value=False),):
            patcher.start()
            self.addCleanup(patcher.stop)

    def run_main(self, lab, argv=()):
        patcher = mock.patch.object(pexpect, "spawn", lab.spawn)
        patcher.start()
        self.addCleanup(patcher.stop)
        buf = io.StringIO()
        env = {"NETLAB_USERNAME": "admin", "NETLAB_PASSWORD": PASSWORD}
        with mock.patch.dict(os.environ, env, clear=True), contextlib.redirect_stdout(buf):
            code = vf.main([self.yaml, "--log-dir", os.path.join(self.tmp, "logs")] + list(argv))
        return code, buf.getvalue()

    def lab(self, vlans):
        r1 = FakeIOS("R1", password=PASSWORD, show={
            "show ip interface brief": "Interface IP-Address OK? Method Status Protocol\n"
                                       "Ethernet0/0 10.1.1.1 YES manual up up"})
        sw1 = FakeIOS("SW1", password=PASSWORD, show={
            "show ip interface brief": "Interface IP-Address OK? Method Status Protocol",
            "show vlan brief": vlan_output(vlans)})
        return FakeLab({"10.0.0.1": r1, "10.0.0.2": sw1})

    def test_dat_thi_exit_0(self):
        code, out = self.run_main(self.lab({10: "Servers"}))
        self.assertEqual(code, 0, out)
        self.assertIn("VERIFY: 0 thất bại", out)

    def test_thieu_vlan_exit_1_va_warn_only_exit_0(self):
        code, out = self.run_main(self.lab({}))
        self.assertEqual(code, 1, out)
        self.assertIn("FAIL  vlan 10 (Servers)", out)
        code, _ = self.run_main(self.lab({}), ["--warn-only"])
        self.assertEqual(code, 0)

    def test_khong_ket_noi_duoc_la_fail(self):
        lab = FakeLab({"10.0.0.1": FakeIOS("R1", password=PASSWORD)})      # SW1 vắng mặt
        code, out = self.run_main(lab)
        self.assertEqual(code, 1)
        self.assertIn("kết nối SSH", out)


GOOD_CONFIG = ("Building configuration...\n\nCurrent configuration : 1234 bytes\n!\nhostname R1\n!\n"
               "interface Ethernet0/0\n ip address 10.1.1.1 255.255.255.0\n!\nend")


class BackupTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.tmp = tmp.name

    def spawn(self, **ios):
        lab = FakeLab({ip.replace("_", "."): d for ip, d in ios.items()})
        patcher = mock.patch.object(pexpect, "spawn", lab.spawn)
        patcher.start()
        self.addCleanup(patcher.stop)

    def dev(self, **extra):
        base = {"name": "R1", "host": "10.0.0.1", "username": "admin", "password": PASSWORD}
        base.update(extra)
        return base

    def test_backup_ghi_file_sach_quyen_600(self):
        self.spawn(**{"10_0_0_1": FakeIOS("R1", password=PASSWORD, show={"show running-config": GOOD_CONFIG})})
        snap = os.path.join(self.tmp, "snap")
        os.makedirs(snap)
        ok, path = bk.backup_device(self.dev(), snap, os.path.join(self.tmp, "logs"))
        self.assertTrue(ok, path)
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
        self.assertNotIn("Building configuration", text)
        self.assertTrue(text.endswith("end\n"), repr(text[-30:]))      # hồi quy: không còn dòng 'R1' rác sau 'end'
        self.assertEqual(os.stat(path).st_mode & 0o777, 0o600)

    def test_output_thieu_end_bi_coi_la_that_bai(self):
        self.spawn(**{"10_0_0_1": FakeIOS("R1", password=PASSWORD,
                                          show={"show running-config": "hostname R1\n!\ninterface Ethernet0/0"})})
        snap = os.path.join(self.tmp, "snap")
        os.makedirs(snap)
        ok, detail = bk.backup_device(self.dev(), snap, os.path.join(self.tmp, "logs"))
        self.assertFalse(ok)
        self.assertIn("hoàn chỉnh", detail)
        self.assertEqual(os.listdir(snap), [])

    def test_prune_chi_xoa_ban_cu_hon_va_dung_dinh_dang(self):
        for name in ("20260101-000000", "20260102-000000", "20260103-000000", "20260104-000000", "khac"):
            os.makedirs(os.path.join(self.tmp, name))
        removed = bk.prune_old_snapshots(self.tmp, keep=2)
        self.assertEqual(removed, ["20260101-000000", "20260102-000000"])
        self.assertEqual(sorted(os.listdir(self.tmp)), ["20260103-000000", "20260104-000000", "khac"])
        self.assertEqual(bk.prune_old_snapshots(self.tmp, keep=0), [])

    def test_clean_va_looks_complete(self):
        self.assertTrue(bk.looks_complete(bk.clean_config_text(GOOD_CONFIG)))
        self.assertFalse(bk.looks_complete("hostname R1\n"))
        self.assertFalse(bk.looks_complete("end\n"))

    def test_display_path_giau_thu_muc_home(self):
        home = os.path.expanduser("~")
        self.assertEqual(bk.display_path(os.path.join(home, "netlab-backups", "x")), "~/netlab-backups/x")
        self.assertEqual(bk.display_path("/srv/x"), "/srv/x")

    def run_main(self, argv):
        yaml_path = os.path.join(self.tmp, "devices.yaml")
        with open(yaml_path, "w", encoding="utf-8") as fh:
            fh.write(_fakes.sample_yaml())
        buf = io.StringIO()
        env = {"NETLAB_USERNAME": "admin", "NETLAB_PASSWORD": PASSWORD}
        with mock.patch.object(nc, "load_dotenv", return_value=False), \
                mock.patch.dict(os.environ, env, clear=True), contextlib.redirect_stdout(buf):
            code = bk.main([yaml_path, "--out-dir", os.path.join(self.tmp, "bk"),
                            "--log-dir", os.path.join(self.tmp, "logs")] + argv)
        return code, buf.getvalue()

    def test_main_ok_exit_0_va_exit_1_khi_thieu_thiet_bi(self):
        show = {"show running-config": GOOD_CONFIG.replace("R1", "SW1")}
        self.spawn(**{"10_0_0_1": FakeIOS("R1", password=PASSWORD, show={"show running-config": GOOD_CONFIG}),
                      "10_0_0_2": FakeIOS("SW1", password=PASSWORD, show=show)})
        code, out = self.run_main([])
        self.assertEqual(code, 0, out)
        self.assertIn("2/2", out)
        code, out = self.run_main(["--only", "R1"])
        self.assertEqual(code, 0)

    def test_main_exit_1_khi_mot_thiet_bi_loi(self):
        self.spawn(**{"10_0_0_1": FakeIOS("R1", password=PASSWORD, show={"show running-config": GOOD_CONFIG})})
        code, out = self.run_main([])
        self.assertEqual(code, 1)
        self.assertIn("FAIL SW1", out)


class PreflightTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.tmp = tmp.name

    def test_tcp_check(self):
        server = socket.socket()
        server.bind(("127.0.0.1", 0))
        server.listen(1)
        self.addCleanup(server.close)
        port = server.getsockname()[1]
        self.assertEqual(pre.tcp_check("127.0.0.1", port, 1.0), (True, ""))
        closed = socket.socket()
        closed.bind(("127.0.0.1", 0))
        free_port = closed.getsockname()[1]
        closed.close()
        ok, reason = pre.tcp_check("127.0.0.1", free_port, 1.0)
        self.assertFalse(ok)
        self.assertTrue(reason)

    def write_yaml(self, port):
        path = os.path.join(self.tmp, "d.yaml")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(f"devices:\n  - name: R1\n    host: 127.0.0.1\n    port: {port}\n    username: admin\n"
                     f"    protocol: ssh\n")
        return path

    def run_main(self, argv):
        buf = io.StringIO()
        env = {"NETLAB_USERNAME": "admin", "NETLAB_PASSWORD": PASSWORD}
        with mock.patch.object(nc, "load_dotenv", return_value=False), \
                mock.patch.dict(os.environ, env, clear=True), contextlib.redirect_stdout(buf):
            code = pre.main(argv)
        return code, buf.getvalue()

    def test_tcp_only_exit_0_khi_cong_mo_va_1_khi_dong(self):
        server = socket.socket()
        server.bind(("127.0.0.1", 0))
        server.listen(1)
        self.addCleanup(server.close)
        code, out = self.run_main([self.write_yaml(server.getsockname()[1]), "--tcp-only", "--timeout", "1"])
        self.assertEqual(code, 0, out)
        closed = socket.socket()
        closed.bind(("127.0.0.1", 0))
        free_port = closed.getsockname()[1]
        closed.close()
        code, out = self.run_main([self.write_yaml(free_port), "--tcp-only", "--timeout", "1"])
        self.assertEqual(code, 1)
        self.assertIn("R1", out)
        self.assertIn("EVE-NG", out)

    def test_ssh_check_tra_ve_dong_ho_thiet_bi(self):
        clock = "10:00:00.000 UTC Wed Oct 7 2026"
        lab = FakeLab({"10.0.0.1": FakeIOS("R1", password=PASSWORD, show={"show clock": clock})})
        with mock.patch.object(pexpect, "spawn", lab.spawn):
            ok, detail = pre.ssh_check({"name": "R1", "host": "10.0.0.1", "username": "admin", "password": PASSWORD},
                                       os.path.join(self.tmp, "logs"))
        self.assertTrue(ok, detail)
        self.assertEqual(detail, "10:00:00.000 UTC Wed Oct 7 2026")      # hồi quy: không phải tên máy 'R1'

    def test_ssh_check_that_bai_khi_sai_mat_khau(self):
        lab = FakeLab({"10.0.0.1": FakeIOS("R1", password="dung")})
        with mock.patch.object(pexpect, "spawn", lab.spawn):
            ok, detail = pre.ssh_check({"name": "R1", "host": "10.0.0.1", "username": "admin", "password": "sai"},
                                       os.path.join(self.tmp, "logs"))
        self.assertFalse(ok)
        self.assertIn("sai username/password", detail)

    def test_thieu_credential_exit_2(self):
        buf = io.StringIO()
        with mock.patch.object(nc, "load_dotenv", return_value=False), \
                mock.patch.dict(os.environ, {}, clear=True), contextlib.redirect_stdout(buf):
            code = pre.main([self.write_yaml(22)])
        self.assertEqual(code, 2)


if __name__ == "__main__":
    unittest.main()

import contextlib
import copy
import io
import os
import re
import tempfile
import unittest
from unittest import mock

import _fakes

import config_builder as cb
import validate as val


def load():
    return cb.load_all_devices([_fakes.DEVICES_YAML])


def find(devices, name):
    return next(d for d in devices if d["name"] == name)


def run_main(module, argv):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        code = module.main(argv)
    return code, buf.getvalue()


class ConfigBuilderTests(unittest.TestCase):
    def test_sinh_lenh_cho_ca_10_thiet_bi(self):
        devices = load()
        self.assertEqual(len(devices), 10)
        for dev in devices:
            with self.subTest(device=dev["name"]):
                commands = cb.build_commands_for_device(dev)
                self.assertTrue(commands)
                self.assertEqual(commands[0], f"hostname {dev['name']}")

    def test_khong_bao_gio_cau_hinh_ip_trong_dai_management(self):
        for dev in load():
            for line in cb.build_commands_for_device(dev):
                with self.subTest(device=dev["name"], line=line):
                    self.assertIsNone(re.match(r"^\s*ip address 172\.16\.184\.", line))

    def test_acl_duoc_dung_lai_tu_dau_de_chay_lai_khong_loi(self):
        commands = cb.build_commands_for_device(find(load(), "HN_GW"))
        idx_no = commands.index("no ip access-list extended HN_TO_INTERNET")
        idx_new = commands.index("ip access-list extended HN_TO_INTERNET")
        self.assertLess(idx_no, idx_new)
        self.assertEqual(commands[idx_new + 1], " 10 permit ip 172.16.110.0 0.0.0.255 any")

    def test_acl_standard_cung_duoc_xoa_truoc(self):
        commands = cb.build_commands_for_device(find(load(), "HN-DATACENTER"))
        self.assertIn("no ip access-list standard ACL_4_DataCenter", commands)

    def test_noi_dung_chinh_cua_router_va_switch(self):
        hn_gw = cb.build_commands_for_device(find(load(), "HN_GW"))
        self.assertIn("ip route 0.0.0.0 0.0.0.0 200.0.0.1", hn_gw)
        self.assertIn("router ospf 1", hn_gw)
        hcm_sw = cb.build_commands_for_device(find(load(), "HCM-SW"))
        self.assertIn("vlan 210", hcm_sw)
        self.assertIn(" name IT", hcm_sw)
        self.assertIn(" switchport access vlan 210", hcm_sw)

    def test_thut_le_sai_vlan_am_bi_bat(self):
        dev = {"name": "SWX", "host": "10.0.0.9", "type": "cisco_ios", "vlans": {-10: "IT"}}
        with self.assertRaises(cb.DeviceConfigError):
            cb.build_commands_for_device(dev)

    def test_main_tra_exit_1_khi_co_thiet_bi_loi(self):
        bad = "devices:\n  - name: SWX\n    host: 10.0.0.9\n    type: cisco_ios\n    vlans:\n      -10: IT\n"
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "bad.yaml")
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(bad)
            with mock.patch("sys.argv", ["config_builder.py", path, "--dry-run"]), \
                    contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaises(SystemExit) as ctx:
                    cb.main()
        self.assertEqual(ctx.exception.code, 1)

    def test_file_yaml_khong_co_devices_bao_loi_ro(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "empty.yaml")
            with open(path, "w", encoding="utf-8") as fh:
                fh.write("")
            with self.assertRaises(ValueError):
                cb.load_all_devices([path])


class ValidateRealDataTests(unittest.TestCase):
    def test_yaml_that_khong_co_loi(self):
        rep = val.validate_devices(load())
        self.assertEqual(rep.errors, [], rep.errors)

    def test_yaml_that_phat_hien_dhcp_gateway_khong_ton_tai(self):
        rep = val.validate_devices(load())
        msgs = [m for d, m in rep.warnings if d == "HCM_GW"]
        self.assertEqual(len(msgs), 3)
        self.assertTrue(all("default-router" in m for m in msgs))

    def test_main_exit_0_voi_yaml_that(self):
        code, out = run_main(val, [_fakes.DEVICES_YAML])
        self.assertEqual(code, 0, out)

    def test_main_strict_bien_canh_bao_thanh_loi(self):
        code, _ = run_main(val, [_fakes.DEVICES_YAML, "--strict"])
        self.assertEqual(code, 1)

    def test_main_file_khong_ton_tai_exit_2(self):
        code, _ = run_main(val, ["/khong/co/file.yaml"])
        self.assertEqual(code, 2)


class ValidateNegativeTests(unittest.TestCase):
    """Mỗi test làm hỏng đúng 1 chỗ trong bản sao của YAML thật và kiểm tra validate bắt được."""

    def setUp(self):
        self.devices = copy.deepcopy(load())

    def errors(self):
        return [f"[{d}] {m}" for d, m in val.validate_devices(self.devices).errors]

    def assert_error(self, fragment):
        joined = "\n".join(self.errors())
        self.assertIn(fragment, joined)

    def test_password_trong_yaml(self):
        find(self.devices, "HN_GW")["password"] = "abc123"
        self.assert_error("'password' nằm trong YAML")

    def test_cho_phep_password_khi_allow_secrets(self):
        find(self.devices, "HN_GW")["password"] = "abc123"
        self.assertEqual(val.validate_devices(self.devices, allow_secrets=True).errors, [])

    def test_trung_ip_interface(self):
        hcm = find(self.devices, "HCM_GW")
        hcm["interfaces"][0]["fa1/0"]["ip"] = "200.0.0.1"          # trùng với FPT_Telecom f3/0
        self.assert_error("200.0.0.1 bị dùng cho nhiều interface")

    def test_ip_interface_nam_trong_dai_management(self):
        find(self.devices, "HN_GW")["interfaces"][0]["fa0/0"]["ip"] = "172.16.184.77"
        self.assert_error("nằm trong dải management")

    def test_ospf_phu_ip_management(self):
        ospf = find(self.devices, "HN_GW")["ospf"]
        ospf["networks"].append({"network": "172.16.184.0", "wildcard": "0.0.0.255", "area": 0})
        self.assert_error("chồng lấn dải management")

    def test_ospf_wildcard_sai(self):
        find(self.devices, "HN_GW")["ospf"]["networks"][0]["wildcard"] = "255.255.255.0"
        self.assert_error("wildcard")

    def test_netmask_sai(self):
        find(self.devices, "HN_GW")["interfaces"][0]["fa0/0"]["netmask"] = "255.0.255.0"
        self.assert_error("không liền khối")

    def test_ip_khong_hop_le(self):
        find(self.devices, "HN_GW")["interfaces"][0]["fa0/0"]["ip"] = "172.16.300.1"
        self.assert_error("không phải địa chỉ IPv4 hợp lệ")

    def test_acl_tham_chieu_khong_ton_tai(self):
        find(self.devices, "HN_GW")["interfaces_acls"][0]["acl"] = "KHONG_CO"
        self.assert_error("chưa được khai báo trong 'acls'")

    def test_interface_gan_acl_khong_ton_tai(self):
        find(self.devices, "HN_GW")["interfaces_acls"][0]["interface"] = "fa9/9"
        self.assert_error("không có trong cấu hình thiết bị")

    def test_nat_dung_acl_khong_ton_tai(self):
        find(self.devices, "HN_GW")["nat"]["rules"][1]["acl"] = "KHONG_CO"
        self.assert_error("ACL 'KHONG_CO' chưa khai báo")

    def test_access_vlan_chua_khai_bao(self):
        find(self.devices, "HCM-SW")["interfaces"][0]["e0/1"]["switchport_access_vlan"] = 999
        self.assert_error("access vlan 999 chưa được khai báo")

    def test_vlan_ngoai_khoang(self):
        find(self.devices, "HCM-SW")["vlans"].append({5000: "Bad"})
        self.assert_error("vlan 5000")

    def test_trung_ten_va_host(self):
        dmz = find(self.devices, "HN-DMZ")
        dmz["host"] = find(self.devices, "HCM-SW")["host"]
        dmz["name"] = "HCM-SW"
        joined = "\n".join(self.errors())
        self.assertIn("tên thiết bị trùng", joined)
        self.assertIn("trùng với thiết bị", joined)

    def test_syslog_level_sai(self):
        find(self.devices, "HN-OFFICE")["syslog"]["level"] = "loud"
        self.assert_error("syslog.level 'loud'")

    def test_thieu_netmask(self):
        del find(self.devices, "HN_GW")["interfaces"][0]["fa0/0"]["netmask"]
        self.assert_error("thiếu 'netmask'")

    def test_main_exit_1_khi_co_password(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "d.yaml")
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(_fakes.sample_yaml().replace("    protocol: ssh", "    password: abc\n    protocol: ssh"))
            code, out = run_main(val, [path])
        self.assertEqual(code, 1)
        self.assertIn("ERROR", out)

    def test_main_exit_0_voi_yaml_mau_sach(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "d.yaml")
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(_fakes.sample_yaml())
            code, out = run_main(val, [path])
        self.assertEqual(code, 0, out)


if __name__ == "__main__":
    unittest.main()

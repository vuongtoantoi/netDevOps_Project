"""validate.py - kiểm tra OFFLINE file devices.yaml (không kết nối thiết bị). Chạy trong CI trước khi merge.

Bắt các lỗi mà nếu để lọt tới thiết bị thật sẽ gây hại:
  * credential (password/secret) nằm trong YAML -> lộ lên GitHub public
  * IPv4 / netmask / wildcard sai; trùng IP giữa các interface; tên/IP quản lý trùng nhau
  * interface/ACL/NAT/DHCP/VLAN tham chiếu tới thứ không tồn tại
  * cấu hình có thể làm MẤT KẾT NỐI QUẢN LÝ (IP interface hoặc OSPF phủ dải management)
  * config_builder không sinh được lệnh cho thiết bị

Cách dùng:
    python3 validate.py devices.yaml
    python3 validate.py devices.yaml --strict            # cảnh báo cũng làm CI đỏ
    python3 validate.py devices.yaml --mgmt-network 172.16.184.0/24

Dải management lấy theo thứ tự: --mgmt-network > khoá 'settings.management_network' trong YAML > mặc định.
Exit code: 0 = không có lỗi | 1 = có lỗi (hoặc có cảnh báo khi --strict) | 2 = không đọc được file.
"""
import argparse
import ipaddress
import re
import sys
from collections import defaultdict

import yaml

import config_builder as cb
import netlab_common as nc
import topology as tp

DEFAULT_MGMT_NETWORK = "172.16.184.0/24"
SECRET_KEYS = ("password", "enable_password", "secret", "enable_secret")
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,62}$")
SYSLOG_LEVELS = {
    "emergencies", "alerts", "critical", "errors", "warnings", "notifications",
    "informational", "debugging", "info",   # 'info' được config_builder đổi thành 'informational'
}
ACL_PROTOCOLS = {"ip", "tcp", "udp", "icmp", "gre", "ospf", "esp", "ahp", "eigrp"}
NAT_RULE_TYPES = {"dynamic", "static", "pat"}


class Report:
    def __init__(self):
        self.errors = []     # list (thiết bị, thông báo)
        self.warnings = []

    def error(self, dev, msg):
        self.errors.append((dev, msg))

    def warn(self, dev, msg):
        self.warnings.append((dev, msg))


# ---------------------------------------------------------------------------
# Kiểm tra giá trị đơn lẻ
# ---------------------------------------------------------------------------

def _ip(rep, dev, value, what):
    try:
        return ipaddress.IPv4Address(str(value))
    except ValueError:
        rep.error(dev, f"{what}: '{value}' không phải địa chỉ IPv4 hợp lệ")
        return None


def _netmask(rep, dev, value, what):
    try:
        mask = int(ipaddress.IPv4Address(str(value)))
    except ValueError:
        rep.error(dev, f"{what}: netmask '{value}' không hợp lệ")
        return False
    inverse = ~mask & 0xFFFFFFFF
    if inverse & (inverse + 1):
        rep.error(dev, f"{what}: netmask '{value}' không liền khối (vd 255.255.255.0)")
        return False
    return True


def _wildcard(rep, dev, value, what):
    try:
        w = int(ipaddress.IPv4Address(str(value)))
    except ValueError:
        rep.error(dev, f"{what}: wildcard '{value}' không hợp lệ")
        return False
    if w & (w + 1):
        rep.error(dev, f"{what}: wildcard '{value}' không hợp lệ (vd 0.0.0.255, không phải 255.255.255.0)")
        return False
    return True


def _int_in(rep, dev, value, lo, hi, what):
    if isinstance(value, bool) or not isinstance(value, int) or not lo <= value <= hi:
        rep.error(dev, f"{what}: '{value}' phải là số nguyên trong khoảng {lo}-{hi}")
        return False
    return True


def _acl_match(rep, dev, value, wildcard, what):
    """source/destination của ACL: 'any', IP đơn (host) hoặc IP + wildcard."""
    if value is None or str(value).lower() == "any":
        return
    if _ip(rep, dev, value, what) and wildcard:
        _wildcard(rep, dev, wildcard, f"{what} wildcard")


# ---------------------------------------------------------------------------
# Kiểm tra từng nhóm cấu hình của 1 thiết bị
# ---------------------------------------------------------------------------

def _check_identity(rep, label, dev, allow_secrets):
    if not isinstance(dev.get("name"), str) or not NAME_RE.match(dev["name"]):
        rep.error(label, f"'name' phải gồm chữ/số/-/_ (tối đa 63 ký tự), hiện là {dev.get('name')!r}")
    if "host" not in dev:
        rep.error(label, "thiếu 'host' (IP quản lý dùng để SSH)")
    else:
        _ip(rep, label, dev["host"], "host")
    if "port" in dev:
        _int_in(rep, label, dev["port"], 1, 65535, "port")
    if "protocol" not in dev and dev.get("type") not in ("cisco_ios", "L3_switch"):
        rep.warn(label, "không có 'protocol' (router) và 'type' không phải cisco_ios/L3_switch (switch): "
                        "config_builder sẽ coi đây là switch")
    if not allow_secrets:
        for key in SECRET_KEYS:
            if dev.get(key):
                rep.error(label, f"'{key}' nằm trong YAML -> sẽ bị lộ khi push lên GitHub public. "
                                 f"Xoá dòng này và đặt qua biến môi trường NETLAB_PASSWORD / NETLAB_ENABLE_PASSWORD")


def _check_interfaces(rep, label, dev, mgmt_net):
    for itf in tp.l3_interfaces(dev):
        what = f"interface {itf['name']}"
        addr = _ip(rep, label, itf["ip"], f"{what} ip")
        if itf["netmask"] is None:
            rep.error(label, f"{what}: có 'ip' nhưng thiếu 'netmask' (lệnh 'ip address' sẽ bị IOS từ chối)")
        else:
            _netmask(rep, label, itf["netmask"], what)
        if addr and mgmt_net and addr in mgmt_net:
            rep.error(label, f"{what}: IP {addr} nằm trong dải management {mgmt_net}. "
                             f"Cấu hình này có thể làm mất kết nối SSH quản lý")
    if not cb.is_router_schema(dev):
        for name, props in tp._safe_interfaces(dev).items():
            if props.get("ip") and not cb.is_svi_name(name):
                rep.warn(label, f"interface {name}: 'ip' bị config_builder bỏ qua vì không phải SVI "
                                f"(cổng routed phải khai báo trong 'routed_interfaces')")
    for tun in dev.get("tunnel") or []:
        for key in ("name", "source", "destination", "ip"):
            if not tun.get(key):
                rep.error(label, f"tunnel {tun.get('name', '?')}: thiếu '{key}'")
        if tun.get("destination"):
            _ip(rep, label, tun["destination"], f"tunnel {tun.get('name', '?')} destination")


def _check_routing(rep, label, dev, mgmt_net):
    for i, route in enumerate(tp.get_static_routes(dev), 1):
        what = f"static route #{i}"
        for key in ("destination", "netmask", "next_hop"):
            if key not in route:
                rep.error(label, f"{what}: thiếu '{key}'")
        if "destination" in route:
            _ip(rep, label, route["destination"], f"{what} destination")
        if "netmask" in route:
            _netmask(rep, label, route["netmask"], what)
        if "next_hop" in route:
            _ip(rep, label, route["next_hop"], f"{what} next_hop")

    ospf = tp.get_ospf(dev)
    if not cb.is_router_schema(dev):
        routing = dev.get("ip_routing") or {}
        if routing.get("ospf", {}).get("enabled") and not routing.get("enabled"):
            rep.warn(label, "ip_routing.ospf bị bỏ qua vì 'ip_routing.enabled' chưa bật")
    if not ospf:
        return
    _int_in(rep, label, ospf.get("process_id"), 1, 65535, "ospf.process_id")
    if not ospf.get("networks"):
        rep.warn(label, "OSPF bật nhưng không có 'networks' nào")
    host = None
    try:
        host = ipaddress.IPv4Address(str(dev.get("host")))
    except ValueError:
        pass
    for entry in ospf.get("networks", []) or []:
        what = f"ospf network {entry.get('network')} {entry.get('wildcard')}"
        ok_ip = _ip(rep, label, entry.get("network"), what)
        ok_wc = _wildcard(rep, label, entry.get("wildcard"), what)
        _int_in(rep, label, entry.get("area"), 0, 4294967295, f"{what} area")
        if ok_ip and ok_wc:
            net = tp.wildcard_to_network(entry["network"], entry["wildcard"])
            if host is not None and host in net:
                rep.error(label, f"{what}: phủ IP quản lý {host} -> interface management sẽ bị kéo vào OSPF")
            if mgmt_net and net.overlaps(mgmt_net):
                rep.error(label, f"{what}: chồng lấn dải management {mgmt_net} -> sẽ quảng bá mạng quản lý vào OSPF")


def _check_acls(rep, label, dev):
    acls = dev.get("acls") or []
    names = set()
    for acl in acls:
        name = acl.get("name")
        if not name:
            rep.error(label, "ACL thiếu 'name'")
            continue
        if name in names:
            rep.error(label, f"ACL '{name}' khai báo trùng tên")
        names.add(name)
        acl_type = acl.get("type", "standard")
        if acl_type not in ("standard", "extended"):
            rep.warn(label, f"ACL '{name}': type '{acl_type}' không phải standard/extended "
                            f"(config_builder sẽ coi là extended)")
        seqs = set()
        for entry in acl.get("entries", []) or []:
            what = f"ACL {name} entry {entry.get('sequence', '?')}"
            if entry.get("action") not in ("permit", "deny"):
                rep.error(label, f"{what}: action phải là permit hoặc deny, hiện là {entry.get('action')!r}")
            if "sequence" in entry:
                if _int_in(rep, label, entry["sequence"], 1, 2147483647, f"{what} sequence"):
                    if entry["sequence"] in seqs:
                        rep.error(label, f"{what}: sequence bị trùng")
                    seqs.add(entry["sequence"])
            _acl_match(rep, label, entry.get("source"), entry.get("wildcard"), f"{what} source")
            if acl_type != "standard":
                if entry.get("protocol", "ip") not in ACL_PROTOCOLS:
                    rep.warn(label, f"{what}: protocol '{entry.get('protocol')}' lạ (hợp lệ: {sorted(ACL_PROTOCOLS)})")
                _acl_match(rep, label, entry.get("destination"), entry.get("destination_wildcard"),
                           f"{what} destination")
                if entry.get("destination_port") is not None:
                    _int_in(rep, label, entry["destination_port"], 1, 65535, f"{what} destination_port")

    own = tp.own_interface_names(dev)
    for bind in dev.get("interfaces_acls") or []:
        what = f"interfaces_acls {bind.get('interface')}/{bind.get('acl')}"
        if bind.get("acl") not in names:
            rep.error(label, f"{what}: ACL '{bind.get('acl')}' chưa được khai báo trong 'acls'")
        if nc.canon_iface(bind.get("interface", "")) not in own:
            rep.error(label, f"{what}: interface '{bind.get('interface')}' không có trong cấu hình thiết bị")
        if bind.get("direction") not in ("in", "out"):
            rep.error(label, f"{what}: direction phải là in hoặc out")
    return names


def _check_nat(rep, label, dev, acl_names):
    nat = dev.get("nat")
    if not nat or not nat.get("enabled"):
        return
    pools = set()
    for pool in nat.get("pools") or []:
        pools.add(pool.get("name"))
        for key in ("start_ip", "end_ip"):
            _ip(rep, label, pool.get(key), f"nat pool {pool.get('name')} {key}")
        _netmask(rep, label, pool.get("netmask"), f"nat pool {pool.get('name')}")
    for i, rule in enumerate(nat.get("rules") or [], 1):
        kind = rule.get("type")
        what = f"nat rule #{i} ({kind})"
        if kind not in NAT_RULE_TYPES:
            rep.error(label, f"{what}: type phải là một trong {sorted(NAT_RULE_TYPES)}")
            continue
        if kind in ("dynamic", "pat") and rule.get("acl") not in acl_names:
            rep.error(label, f"{what}: ACL '{rule.get('acl')}' chưa khai báo trong 'acls'")
        if kind == "dynamic" and rule.get("pool") not in pools:
            rep.error(label, f"{what}: pool '{rule.get('pool')}' chưa khai báo trong 'nat.pools'")
        if kind == "static":
            _ip(rep, label, rule.get("inside_local", rule.get("insideLocal")), f"{what} inside_local")
        if kind in ("static", "pat"):
            _ip(rep, label, rule.get("inside_global", rule.get("insideGlobal")), f"{what} inside_global")
    roles = {p.get("nat_role") for p in tp._safe_interfaces(dev).values()}
    if not {"inside", "outside"} <= roles:
        rep.warn(label, "NAT bật nhưng thiếu interface 'nat_role: inside' hoặc 'nat_role: outside'")


def _check_dhcp(rep, label, dev):
    dhcp = dev.get("dhcp")
    if not dhcp or not dhcp.get("enabled"):
        return
    own_ips = {i["ip"] for i in tp.l3_interfaces(dev)}
    for pool in dhcp.get("pools") or []:
        what = f"dhcp pool {pool.get('name')}"
        _ip(rep, label, pool.get("network"), f"{what} network")
        _netmask(rep, label, pool.get("netmask"), what)
        for ex in pool.get("excluded_add") or []:
            _ip(rep, label, ex, f"{what} excluded_add")
        gw = pool.get("ip_default_gateway")
        if gw and _ip(rep, label, gw, f"{what} ip_default_gateway") and gw not in own_ips:
            rep.warn(label, f"{what}: default-router {gw} KHÔNG phải IP của interface nào trên thiết bị này "
                            f"(client sẽ nhận gateway không tồn tại). IP interface cùng subnet: "
                            f"{sorted(i for i in own_ips if _same_net(i, pool))}")


def _same_net(ip, pool):
    try:
        return ipaddress.IPv4Address(ip) in ipaddress.IPv4Network(f"{pool['network']}/{pool['netmask']}", strict=False)
    except (KeyError, ValueError):
        return False


def _check_switch(rep, label, dev):
    if cb.is_router_schema(dev):
        return
    try:
        vlans = cb.normalize_vlans(dev)
    except cb.DeviceConfigError:
        return   # lỗi này đã được báo ở bước dựng lệnh
    for vid, vname in vlans.items():
        _int_in(rep, label, vid, 1, 4094, f"vlan {vid}")
        if not isinstance(vname, str) or not vname or " " in vname:
            rep.error(label, f"vlan {vid}: tên '{vname}' phải là chuỗi không rỗng, không có khoảng trắng")
    for name, props in tp._safe_interfaces(dev).items():
        access_vlan = props.get("switchport_access_vlan")
        if access_vlan is not None and access_vlan not in vlans:
            rep.error(label, f"interface {name}: access vlan {access_vlan} chưa được khai báo trong 'vlans'")
        if cb.is_svi_name(name):
            svi_id = int(re.sub(r"\D", "", name))
            if svi_id not in vlans:
                rep.warn(label, f"interface {name}: VLAN {svi_id} chưa khai báo trong 'vlans' (SVI sẽ down)")
    for item in dev.get("interfaces-range") or []:
        for key, props in item.items():
            try:
                cb.parse_interface_range(key)
            except ValueError as e:
                rep.error(label, str(e))
            if not isinstance(props, dict) or "channel-group" not in props:
                rep.error(label, f"interfaces-range {key}: thiếu 'channel-group'")


def _check_services(rep, label, dev):
    for block in ("ntp", "syslog"):
        cfg = dev.get(block) or {}
        if cfg.get("enabled"):
            for server in cb.as_list(cfg.get("servers")):
                _ip(rep, label, server, f"{block} server")
    level = (dev.get("syslog") or {}).get("level")
    if level and level not in SYSLOG_LEVELS:
        rep.error(label, f"syslog.level '{level}' không hợp lệ (hợp lệ: {sorted(SYSLOG_LEVELS)})")
    tftp = dev.get("tftp") or {}
    if tftp.get("backup_config") and not cb.get_tftp_server(tftp):
        rep.error(label, "tftp.backup_config bật nhưng thiếu 'server'")
    if cb.get_tftp_server(tftp):
        for server in cb.as_list(cb.get_tftp_server(tftp)):
            _ip(rep, label, server, "tftp server")


# ---------------------------------------------------------------------------
# Kiểm tra toàn cục (nhiều thiết bị)
# ---------------------------------------------------------------------------

def _check_global(rep, devices):
    names, hosts, ips = {}, {}, defaultdict(list)
    all_ips = set()
    for dev in devices:
        label = dev.get("name", "?")
        key = str(label).lower()
        if key in names:
            rep.error(label, f"tên thiết bị trùng với thiết bị khác ('{names[key]}')")
        names[key] = label
        host = str(dev.get("host"))
        if host in hosts:
            rep.error(label, f"host {host} trùng với thiết bị '{hosts[host]}'")
        hosts[host] = label
        for itf in tp.l3_interfaces(dev):
            ips[itf["ip"]].append(f"{label}:{itf['name']}")
            all_ips.add(itf["ip"])
    for ip, owners in ips.items():
        if len(owners) > 1:
            rep.error("topology", f"IP {ip} bị dùng cho nhiều interface: {', '.join(owners)}")

    for dev in devices:
        label = dev.get("name", "?")
        for tun in dev.get("tunnel") or []:
            dest = str(tun.get("destination"))
            if dest not in all_ips:
                rep.warn(label, f"tunnel {tun.get('name')}: destination {dest} không phải IP của interface nào "
                                f"trong YAML (đầu kia của GRE có được quản lý bởi repo này không?)")

    snmp_devs = [d.get("name") for d in devices if (d.get("snmp") or {}).get("enabled") and d["snmp"].get("community")]
    if snmp_devs:
        rep.warn("topology", f"SNMP community nằm trong YAML ({len(snmp_devs)} thiết bị: {', '.join(snmp_devs)}). "
                             f"Community RO của lab thì chấp nhận được; đừng dùng community của hệ thống thật")


def validate_devices(devices, mgmt_network=DEFAULT_MGMT_NETWORK, allow_secrets=False):
    """Kiểm tra danh sách thiết bị (list dict từ load_all_devices). Trả về Report."""
    rep = Report()
    mgmt_net = ipaddress.IPv4Network(mgmt_network) if mgmt_network else None
    if not devices:
        rep.error("topology", "không có thiết bị nào trong file YAML")
        return rep
    for idx, dev in enumerate(devices):
        label = dev["name"] if isinstance(dev.get("name"), str) and dev.get("name") else f"devices[{idx}]"
        _check_identity(rep, label, dev, allow_secrets)
        try:
            cb.build_commands_for_device(dev)
        except cb.DeviceConfigError as e:
            rep.error(label, f"config_builder: {e}")
        except Exception as e:  # noqa: BLE001 - muốn thấy mọi kiểu lỗi dữ liệu
            rep.error(label, f"config_builder không sinh được lệnh ({type(e).__name__}: {e})")
        _check_interfaces(rep, label, dev, mgmt_net)
        _check_routing(rep, label, dev, mgmt_net)
        acl_names = _check_acls(rep, label, dev)
        _check_nat(rep, label, dev, acl_names)
        _check_dhcp(rep, label, dev)
        _check_switch(rep, label, dev)
        _check_services(rep, label, dev)
    _check_global(rep, devices)
    return rep


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def read_settings(paths):
    """Khoá tuỳ chọn 'settings:' ở đầu file YAML (nếu có)."""
    settings = {}
    for path in paths:
        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
        if isinstance(data, dict) and isinstance(data.get("settings"), dict):
            settings.update(data["settings"])
    return settings


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="+", help="file YAML thiết bị")
    ap.add_argument("--strict", action="store_true", help="cảnh báo cũng làm lệnh thất bại (exit 1)")
    ap.add_argument("--allow-secrets", action="store_true",
                    help="cho phép password trong YAML (chỉ dùng tạm khi local)")
    ap.add_argument("--mgmt-network", default=None, help=f"dải management (mặc định {DEFAULT_MGMT_NETWORK})")
    args = ap.parse_args(argv)

    try:
        devices = cb.load_all_devices(args.files)
        settings = read_settings(args.files)
    except Exception as e:  # noqa: BLE001
        print(f"LỖI: không đọc được YAML: {type(e).__name__}: {e}")
        nc.annotate("error", f"Không đọc được YAML: {e}", title="validate")
        return 2

    mgmt = args.mgmt_network or settings.get("management_network") or DEFAULT_MGMT_NETWORK
    try:
        ipaddress.IPv4Network(mgmt)
    except ValueError:
        print(f"LỖI: dải management '{mgmt}' không hợp lệ")
        return 2

    rep = validate_devices(devices, mgmt_network=mgmt, allow_secrets=args.allow_secrets)
    for dev, msg in rep.errors:
        print(f"ERROR  [{dev}] {msg}")
        nc.annotate("error", f"[{dev}] {msg}", title="validate", file=args.files[0])
    for dev, msg in rep.warnings:
        print(f"WARN   [{dev}] {msg}")
        nc.annotate("warning", f"[{dev}] {msg}", title="validate", file=args.files[0])
    print(f"\nĐã kiểm tra {len(devices)} thiết bị (dải management {mgmt}): "
          f"{len(rep.errors)} lỗi, {len(rep.warnings)} cảnh báo.")

    summary = [f"### Kiểm tra YAML: {len(rep.errors)} lỗi, {len(rep.warnings)} cảnh báo", ""]
    summary += [f"- ❌ **[{d}]** {m}" for d, m in rep.errors] + [f"- ⚠️ **[{d}]** {m}" for d, m in rep.warnings]
    nc.write_step_summary("\n".join(summary))

    if rep.errors or (args.strict and rep.warnings):
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

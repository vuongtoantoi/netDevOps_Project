# Tài liệu pipeline CI/CD

## 1. Luồng làm việc (GitOps)

1. Tạo nhánh mới, sửa `main_project/devices.yaml` (nguồn sự thật duy nhất của cấu hình mạng).
2. Mở Pull Request vào `master` -> **CI** chạy tự động (không chạm lab). Phải xanh mới merge được (branch protection).
3. Merge vào `master` -> **CD** khởi động trên self-hosted runner và chờ người duyệt ở Environment `lab`.
4. Sau khi duyệt: `preflight` (lab có bật không?) -> `backup` (lưu running-config) -> `deploy` (đẩy cấu hình, dừng
   ở thiết bị lỗi đầu tiên) -> `verify` (mạng có chạy đúng như YAML mô tả không?).
5. Kết quả từng bước hiện ở tab **Summary** của lần chạy.

Chạy tay: tab *Actions* -> *CD* -> *Run workflow* (chọn thiết bị cần deploy, hoặc `dry_run` để chỉ kiểm tra).

## 2. Mô hình bảo mật

Repo là **public** và runner nằm trong mạng lab, nên rủi ro lớn nhất là người lạ chạy mã trên máy runner.

| Lớp bảo vệ | Cách thực hiện | Được kiểm tra bởi |
|---|---|---|
| CD không nhận Pull Request | `cd.yml` chỉ có `push` (master) và `workflow_dispatch` | `test_cd_chi_duoc_kich_hoat_boi_push_hoac_chay_tay` |
| CI không bao giờ dùng runner của lab | `ci.yml` chạy `ubuntu-24.04` | `test_chi_cd_moi_duoc_dung_self_hosted_runner` |
| Không dùng `pull_request_target` | - | `test_khong_dung_pull_request_target` |
| Credential ngoài Git | GitHub Environment `lab` + `.env` local bị `.gitignore` | `test_khong_co_mat_khau_cung_...`, `test_khong_co_file_env_...` |
| Log không chứa mật khẩu | `logfile_read` thay vì `logfile` | `test_mat_khau_khong_bi_ghi_vao_log` |
| Log công khai không lộ đường dẫn máy | Backup chỉ lưu trên runner, không upload artifact | `test_display_path_...` |
| Token GitHub tối thiểu | `permissions: contents: read`, `persist-credentials: false` | `test_quyen_gitub_token_toi_thieu` |
| Chống chèn lệnh shell | Input đi qua biến môi trường + lọc regex | `test_khong_noi_chuoi_do_nguoi_dung_...` |
| Không lỡ làm mất kết nối quản lý | `validate.py` cấm IP/OSPF chạm dải management | `test_ip_interface_nam_trong_dai_management`... |
| Action không bị đổi ngầm | Ghim phiên bản + Dependabot | `test_action_duoc_ghim_phien_ban` |

Thiết lập phía GitHub (không nằm trong code): Environment `lab` có *Required reviewers* và chỉ cho phép nhánh
`master`; *Actions -> General -> Fork pull request workflows* = "Require approval for all outside collaborators";
branch protection cho `master` bắt buộc PR + CI xanh.

## 3. Các script

| Script | Mục đích | Exit code |
|---|---|---|
| `validate.py` | Kiểm tra YAML offline (IP, tham chiếu, an toàn, không có credential) | 0 ok, 1 lỗi, 2 không đọc được file |
| `preflight.py` | TCP/22 + đăng nhập SSH tới mọi thiết bị | 0 sẵn sàng, 1 có thiết bị chưa sẵn sàng |
| `backup.py` | Lưu `show running-config` trên máy runner | 0 đủ, 1 có thiết bị lỗi |
| `deploy_pexpect.py` | Đẩy cấu hình, `write memory` nếu không có lệnh bị từ chối | 0 ok, 1 lỗi, 2 sai tham số/thiếu credential |
| `verify.py` | Kiểm thử sau deploy suy ra từ YAML | 0 đạt, 1 thất bại |

## 4. Rollback và khôi phục

* **Rollback kiểu GitOps:** `git revert <commit>` rồi push -> CD đẩy lại trạng thái trước. Đây là cách chính.
* **Khôi phục từ backup:** bản chụp trước mỗi lần deploy nằm trên máy runner tại `~/netlab-backups/<ngày-giờ>/<thiết-bị>.cfg`.
  Mở file và dán lại phần cần khôi phục (hoặc `configure replace` nếu image hỗ trợ).
* **Khi deploy báo lỗi:** script không chạy `write memory`, nên startup-config vẫn là bản cũ; `reload` thiết bị sẽ quay về
  trạng thái đã lưu (running-config có thể đã bị thay đổi một phần).

## 5. Hạn chế đã biết

* `config_builder` chủ yếu **thêm** cấu hình: xoá một VLAN/route/interface khỏi YAML không tự xoá trên thiết bị.
  Riêng **ACL** được dựng lại hoàn toàn mỗi lần (`no ip access-list ...` rồi tạo lại), nên sửa/xoá dòng ACL có hiệu lực;
  đổi lại ACL biến mất trong vài giây lúc cập nhật.
* `verify.py` kiểm tra interface, VLAN, OSPF và ping từng liên kết; chưa có kiểm thử đầu-cuối giữa các site.
* SSH dùng `StrictHostKeyChecking=no` và thuật toán cũ vì image lab cũ - chấp nhận được trong mạng OOB của lab, không dùng cho mạng thật.
* Runner là máy cá nhân: nếu Ubuntu hoặc EVE-NG tắt, job sẽ chờ trong hàng đợi hoặc fail ở `preflight`.

## 6. Xử lý sự cố

| Triệu chứng | Nguyên nhân thường gặp |
|---|---|
| Job CD chờ mãi ở trạng thái *Queued* | Runner offline (`sudo ./svc.sh status`) hoặc nhãn `netlab` không khớp |
| Job CD chờ ở *Waiting* | Đang chờ người duyệt ở Environment `lab` |
| `preflight` FAIL | EVE-NG chưa bật lab / node chưa boot xong / máy Ubuntu không tới được dải 172.16.184.0/24 |
| `Thiếu credential` | Chưa tạo secret `NETLAB_USERNAME` / `NETLAB_PASSWORD` trong Environment `lab` |
| `deploy` báo lệnh bị từ chối | Xem dòng `=>` trong log: đó là thông báo `% ...` của IOS cho đúng lệnh bị lỗi |
| `verify` FAIL ở OSPF | Thiết bị đầu kia chưa được deploy, hoặc interface giữa hai thiết bị đang down |

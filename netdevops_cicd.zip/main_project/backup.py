"""backup.py - sao lưu 'show running-config' của thiết bị TRƯỚC khi deploy.

Bản sao lưu được lưu trên CHÍNH MÁY CHẠY RUNNER (mặc định ~/netlab-backups/<ngày-giờ>/<thiết-bị>.cfg),
quyền 600. KHÔNG upload làm artifact và KHÔNG commit vào Git, vì repo này public.

Cách dùng:
    python3 backup.py devices.yaml
    python3 backup.py devices.yaml --out-dir /srv/netlab-backups --keep 50
    python3 backup.py devices.yaml --only HN_GW

Biến môi trường: NETLAB_BACKUP_DIR (thay cho --out-dir).
Exit code: 0 = backup đủ | 1 = có thiết bị backup lỗi (CD sẽ dừng, không deploy) | 2 = sai tham số / thiếu credential.
"""
import argparse
import os
import re
import shutil
import sys
import time

import deploy_pexpect as dp
import netlab_common as nc

STAMP_RE = re.compile(r"^\d{8}-\d{6}$")


def display_path(path):
    """Rút gọn đường dẫn home thành '~' để log công khai (repo public) không lộ tên user trên máy runner."""
    home = os.path.expanduser("~")
    return path.replace(home, "~", 1) if path.startswith(home) else path


def default_out_dir():
    return os.environ.get("NETLAB_BACKUP_DIR") or os.path.join(os.path.expanduser("~"), "netlab-backups")


def clean_config_text(raw):
    """Chuẩn hóa output 'show running-config': bỏ ký tự \\r và dòng 'Building configuration...'."""
    lines = raw.replace("\r", "").split("\n")
    lines = [ln for ln in lines if not ln.strip().lower().startswith("building configuration")]
    return "\n".join(lines).strip("\n") + "\n"


def looks_complete(text):
    """Cấu hình đầy đủ phải có 'hostname' và kết thúc bằng dòng 'end'."""
    return bool(re.search(r"^hostname\s+\S+", text, re.MULTILINE)) and bool(re.search(r"^end\s*$", text, re.MULTILINE))


def write_private(path, text):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(text)


def backup_device(device, snapshot_dir, log_dir):
    """Backup 1 thiết bị. Trả về (True, đường dẫn file) hoặc (False, lý do)."""
    child = None
    try:
        child = dp.connect(device, log_dir)
        raw = dp.run_command(child, "show running-config", timeout=90)
        child.sendline("exit")
    except Exception as e:  # noqa: BLE001
        return False, f"{type(e).__name__}: {e}"
    finally:
        dp.close_session(child)

    text = clean_config_text(raw)
    if not looks_complete(text):
        return False, "output không giống một running-config hoàn chỉnh (thiếu hostname hoặc dòng 'end')"
    path = os.path.join(snapshot_dir, f"{device['name']}.cfg")
    write_private(path, text)
    return True, path


def prune_old_snapshots(out_dir, keep):
    """Giữ lại `keep` bản chụp mới nhất, xoá phần cũ hơn. Trả về danh sách thư mục đã xoá."""
    if keep <= 0 or not os.path.isdir(out_dir):
        return []
    stamps = sorted(d for d in os.listdir(out_dir)
                    if STAMP_RE.match(d) and os.path.isdir(os.path.join(out_dir, d)))
    removed = []
    for old in stamps[:-keep]:
        shutil.rmtree(os.path.join(out_dir, old), ignore_errors=True)
        removed.append(old)
    return removed


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="+", help="file YAML thiết bị")
    ap.add_argument("--only", nargs="*", help="chỉ backup các thiết bị có tên này")
    ap.add_argument("--out-dir", default=None, help="thư mục gốc chứa các bản backup (mặc định ~/netlab-backups)")
    ap.add_argument("--keep", type=int, default=30, help="số bản chụp giữ lại (mặc định 30; 0 = không xoá)")
    ap.add_argument("--log-dir", default="logs", help="thư mục log phiên SSH")
    args = ap.parse_args(argv)
    nc.load_dotenv()

    try:
        devices = dp.load_devices(args.files, args.only)
        for d in devices:
            d.update(nc.resolve_credentials(d))
    except (ValueError, OSError, nc.CredentialError) as e:
        print(f"LỖI: {e}")
        return 2

    out_dir = args.out_dir or default_out_dir()
    snapshot = os.path.join(out_dir, time.strftime("%Y%m%d-%H%M%S"))
    os.makedirs(snapshot, mode=0o700, exist_ok=True)
    print(f"Backup running-config vào: {display_path(snapshot)}")

    ok, failed = [], []
    for dev in devices:
        success, detail = backup_device(dev, snapshot, args.log_dir)
        if success:
            ok.append(dev["name"])
            print(f"  OK   {dev['name']:15s} -> {os.path.basename(detail)} ({os.path.getsize(detail)} bytes)")
        else:
            failed.append(dev["name"])
            print(f"  FAIL {dev['name']:15s} {detail}")
            nc.annotate("error", f"{dev['name']}: {detail}", title="Backup lỗi")

    removed = prune_old_snapshots(out_dir, args.keep)
    if removed:
        print(f"Đã xoá {len(removed)} bản backup cũ (giữ {args.keep} bản mới nhất).")
    print(f"\nBackup: {len(ok)}/{len(devices)} thiết bị thành công.")
    nc.write_step_summary(f"### Backup trước khi deploy: {len(ok)}/{len(devices)} thiết bị\n\n"
                          "Lưu trên máy chạy runner (không public, không nằm trong Git).")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())

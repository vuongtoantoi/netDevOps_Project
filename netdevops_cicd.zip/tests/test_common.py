import contextlib
import io
import os
import tempfile
import unittest
from unittest import mock

import _fakes

import config_builder as cb
import netlab_common as nc
import topology as tp


class ErrorLineTests(unittest.TestCase):
    def test_nhan_dien_loi_that_va_bo_qua_thong_tin(self):
        sample = (
            " 10 permit ip 1.1.1.0 0.0.0.255 any\r\n"
            "% Duplicate sequence number\r\n"
            "%Warning: portfast should only be enabled on ports connected to a single\r\n"
            "%Portfast has been configured on Ethernet0/1 but will only\r\n"
            "%LINK-3-UPDOWN: Interface Ethernet0/0, changed state to up\r\n"
            "% Invalid input detected at '^' marker.\r\n"
            "%Pool X overlaps with pool Y\r\n"
            "*Oct  7 12:00:00: %SYS-5-CONFIG_I: Configured from console\r\n"
        )
        self.assertEqual(
            nc.find_error_lines(sample),
            ["% Duplicate sequence number", "% Invalid input detected at '^' marker.", "%Pool X overlaps with pool Y"],
        )

    def test_rong(self):
        self.assertEqual(nc.find_error_lines(""), [])
        self.assertEqual(nc.find_error_lines(None), [])


class CanonIfaceTests(unittest.TestCase):
    def test_ten_viet_tat_bang_ten_day_du(self):
        pairs = [("e1/0", "Ethernet1/0"), ("f0/0", "FastEthernet0/0"), ("fa0/0.210", "FastEthernet0/0.210"),
                 ("Po1", "Port-channel1"), ("vlan110", "Vlan110"), ("tunnel0", "Tunnel0"), ("Et0/1", "Ethernet0/1"),
                 ("gi1/0/1", "GigabitEthernet1/0/1")]
        for short, full in pairs:
            with self.subTest(short=short):
                self.assertEqual(nc.canon_iface(short), nc.canon_iface(full))

    def test_khac_nhau_thi_khac(self):
        self.assertNotEqual(nc.canon_iface("e0/1"), nc.canon_iface("e0/2"))
        self.assertNotEqual(nc.canon_iface("fa0/0"), nc.canon_iface("e0/0"))


class CredentialTests(unittest.TestCase):
    def test_env_uu_tien_hon_yaml(self):
        env = {"NETLAB_USERNAME": "envuser", "NETLAB_PASSWORD": "envpw"}
        creds = nc.resolve_credentials({"username": "yamluser", "password": "yamlpw"}, env)
        self.assertEqual(creds, {"username": "envuser", "password": "envpw", "enable_password": "envpw"})

    def test_enable_rieng(self):
        env = {"NETLAB_USERNAME": "u", "NETLAB_PASSWORD": "p", "NETLAB_ENABLE_PASSWORD": "e"}
        self.assertEqual(nc.resolve_credentials({}, env)["enable_password"], "e")

    def test_thieu_credential_nem_loi_ro_rang(self):
        with self.assertRaises(nc.CredentialError) as ctx:
            nc.resolve_credentials({}, {})
        self.assertIn("NETLAB_PASSWORD", str(ctx.exception))

    def test_dotenv_khong_ghi_de_bien_da_co(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, ".env")
            with open(path, "w", encoding="utf-8") as fh:
                fh.write("# c\nNETLAB_USERNAME=fromfile\nexport NETLAB_PASSWORD='p w'\nrác\n")
            env = {"NETLAB_USERNAME": "fromci"}
            self.assertTrue(nc.load_dotenv(path, env))
            self.assertEqual(env["NETLAB_USERNAME"], "fromci")      # CI secret thắng file .env
            self.assertEqual(env["NETLAB_PASSWORD"], "p w")

    def test_khong_co_file_env_khong_loi(self):
        self.assertFalse(nc.load_dotenv("/khong/ton/tai/.env", {}))


class GithubHelperTests(unittest.TestCase):
    def test_step_summary(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "summary.md")
            self.assertTrue(nc.write_step_summary("### a", {"GITHUB_STEP_SUMMARY": path}))
            self.assertTrue(nc.write_step_summary("### b", {"GITHUB_STEP_SUMMARY": path}))
            with open(path, encoding="utf-8") as fh:
                self.assertEqual(fh.read(), "### a\n\n### b\n\n")
        self.assertFalse(nc.write_step_summary("x", {}))

    def test_annotate_chi_in_khi_chay_tren_github(self):
        buf = io.StringIO()
        with mock.patch.dict(os.environ, {"GITHUB_ACTIONS": "true"}), contextlib.redirect_stdout(buf):
            nc.annotate("error", "dòng 1\ndòng 2", title="a,b", file="x.yaml")
        self.assertEqual(buf.getvalue().strip(), "::error file=x.yaml,title=a%2Cb::dòng 1%0Adòng 2")
        buf = io.StringIO()
        with mock.patch.dict(os.environ, {"GITHUB_ACTIONS": ""}), contextlib.redirect_stdout(buf):
            nc.annotate("error", "x")
        self.assertEqual(buf.getvalue(), "")


class TopologyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.devices = cb.load_all_devices([_fakes.DEVICES_YAML])

    def test_wildcard_to_network(self):
        self.assertEqual(str(tp.wildcard_to_network("10.0.255.0", "0.0.0.3")), "10.0.255.0/30")
        self.assertEqual(str(tp.wildcard_to_network("10.0.0.5", "0.0.0.0")), "10.0.0.5/32")
        with self.assertRaises(ValueError):
            tp.wildcard_to_network("10.0.0.0", "255.255.255.0")

    def test_6_lien_ket_point_to_point_dung_voi_so_do(self):
        links = {frozenset([(a[0], a[2]), (b[0], b[2])]) for a, b in tp.link_peers(self.devices)}
        expected = {
            frozenset([("FPT_Telecom", "f2/0"), ("HCM_GW", "fa1/0")]),
            frozenset([("FPT_Telecom", "f3/0"), ("HN_GW", "fa1/0")]),
            frozenset([("HCM_GW", "tunnel0"), ("HN_GW", "tunnel0")]),
            frozenset([("HN_GW", "fa2/0"), ("HN-OFFICE", "e0/0")]),
            frozenset([("HN_GW", "fa3/0"), ("HN-DATACENTER", "e0/0")]),
            frozenset([("HN-OFFICE", "e1/2"), ("HN-DATACENTER", "e1/2")]),
        }
        self.assertEqual(links, expected)

    def test_lang_gieng_ospf_ky_vong(self):
        self.assertEqual(tp.expected_ospf_neighbors(self.devices),
                         {"HN_GW": 2, "HN-OFFICE": 2, "HN-DATACENTER": 2})

    def test_interface_shutdown_khong_tinh_la_lien_ket(self):
        devices = cb.load_all_devices([_fakes.DEVICES_YAML])
        for dev in devices:
            if dev["name"] == "HN_GW":
                for item in dev["interfaces"]:
                    if "fa2/0" in item:
                        item["fa2/0"]["shutdown"] = True
        self.assertEqual(tp.expected_ospf_neighbors(devices)["HN-OFFICE"], 1)


if __name__ == "__main__":
    unittest.main()
